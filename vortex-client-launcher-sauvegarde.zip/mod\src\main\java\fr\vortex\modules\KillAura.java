package fr.vortex.modules;

import fr.vortex.Hack;
import fr.vortex.VortexClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * KillAura : frappe automatique, mais propre.
 *
 * - respecte le cooldown vanilla (>= 95 %) et le CPS demandé ;
 * - vise la cible avant de frapper (rotation douce, pas de snap) ;
 * - vérifie la portée réelle du joueur ;
 * - option « clic maintenu » pour ne pas frapper quand tu manges / construis.
 *
 * Sans ces garde-fous, l'aura spamme des coups à dégâts nuls et rend le PvP
 * injouable : c'était le cas avant.
 */
public class KillAura extends Hack {
    public static double RANGE = 3.2;
    public static int CPS = 8;
    public static boolean PLAYERS_ONLY = true;
    public static boolean WALLS = false;
    public static boolean ROTATE = true;       // viser la cible avant de frapper
    public static boolean CLICK_ONLY = false;  // frapper seulement si clic gauche maintenu
    public static boolean CRIT = false;        // petit saut pour les coups critiques
    public static double PREDICT = 1.0;        // ticks d'avance sur la cible

    private long lastAttack;
    private int targetId = -1;

    public KillAura() { super("KillAura"); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        LivingEntity best = findTarget();
        if (best == null) {
            targetId = -1;
            return;
        }

        // viser : on laisse l'Aimbot gérer la caméra s'il est actif
        if (ROTATE && !VortexClient.isEnabled("Aimbot")) {
            Vec3d v = best.getVelocity();
            Vec3d point = new Vec3d(
                best.getX() + v.x * PREDICT,
                best.getY() + best.getHeight() * 0.55 + Math.max(0, v.y) * PREDICT * 0.5,
                best.getZ() + v.z * PREDICT);
            Aimbot.aimPoint(point);
        }

        if (CLICK_ONLY && !mc.options.attackKey.isPressed()) return;

        long now = System.currentTimeMillis();
        if (now - lastAttack < 1000L / Math.max(1, CPS)) return;
        if (p.getAttackCooldownProgress(0f) < 0.95f) return;

        double reach = p.getEntityInteractionRange();
        if (p.squaredDistanceTo(best) > reach * reach) return;
        if (!WALLS && !p.canSee(best)) return;

        // coup critique : on saute, la frappe partira au tick suivant en descente
        if (CRIT && p.isOnGround()) {
            p.jump();
            return;
        }

        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        lastAttack = now;
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        var p = mc.player;
        Vec3d look = p.getRotationVec(1f);
        Vec3d eye = p.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
            if (le.isSpectator()) continue;
            if (PLAYERS_ONLY && !(le instanceof PlayerEntity)) continue;
            double d2 = p.squaredDistanceTo(le);
            if (d2 > RANGE * RANGE) continue;
            if (!WALLS && !p.canSee(le)) continue;

            // privilégie la cible la plus proche du viseur, pas seulement la plus proche
            Vec3d dir = le.getBoundingBox().getCenter().subtract(eye);
            double len = dir.length();
            double angle = 0;
            if (len > 1e-4) {
                double cos = dir.dotProduct(look) / len;
                angle = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, cos))));
            }
            double score = angle * 1.5 + d2 * 4.0;
            if (score < bestScore) { bestScore = score; best = le; }
        }
        return best;
    }
}
