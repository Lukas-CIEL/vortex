package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

/**
 * AutoEat : mange automatiquement quand la barre de faim descend sous le seuil.
 * Cherche la nourriture dans la barre rapide, sélectionne le bon slot, puis
 * utilise l'item (interaction vanilla).
 */
public class AutoEat extends Hack {
    public static int THRESHOLD = 16;
    public static boolean OFFHAND = true;   // accepter la nourriture en main secondaire

    private int cooldown;

    public AutoEat() { super("AutoEat"); }

    @Override public void onEnable() { cooldown = 0; }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (p.getHungerManager().getFoodLevel() > THRESHOLD) return;
        if (p.isUsingItem()) return;
        if (cooldown > 0) { cooldown--; return; }

        var inv = p.getInventory();
        int food = -1;
        for (int i = 0; i < 9; i++) {
            if (isFood(inv.getStack(i))) { food = i; break; }
        }
        if (food < 0) {
            if (OFFHAND && isFood(p.getOffHandStack())) {
                mc.interactionManager.interactItem(p, Hand.OFF_HAND);
                p.swingHand(Hand.OFF_HAND);
                cooldown = 12;
            }
            return;
        }
        if (inv.getSelectedSlot() != food) {
            inv.setSelectedSlot(food);
            cooldown = 2;
            return;
        }
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        cooldown = 12;
    }

    private static boolean isFood(ItemStack stack) {
        return !stack.isEmpty() && stack.contains(DataComponentTypes.FOOD);
    }
}
