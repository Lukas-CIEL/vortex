package fr.vortex.modules;
import fr.vortex.Hack;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Identifier;
/**
 * Reach : allonge très légèrement la portée d'attaque (3.2 au lieu de 3.0).
 * On reste sous les seuils des anticheat (3.3+), donc c'est la version « discrète ».
 * Le serveur vanilla, lui, autorise jusqu'à 6 blocs : aucun risque de kick.
 */
public class Reach extends Hack {
    public static double REACH = 3.2;
    private static final Identifier ID = Identifier.of("vortex", "reach");
    private static final EntityAttributeModifier MOD = new EntityAttributeModifier(
        ID, REACH - 3.0, EntityAttributeModifier.Operation.ADD_VALUE);

    public Reach() { super("Reach"); }

    @Override public void onEnable() { apply(true); }
    @Override public void onDisable() { apply(false); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        var inst = p.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
        if (inst != null && !inst.hasModifier(ID)) inst.addTemporaryModifier(MOD);
    }

    private void apply(boolean add) {
        var p = mc.player;
        if (p == null) return;
        EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
        if (inst == null) return;
        if (add) { if (!inst.hasModifier(ID)) inst.addTemporaryModifier(MOD); }
        else inst.removeModifier(ID);
    }
}
