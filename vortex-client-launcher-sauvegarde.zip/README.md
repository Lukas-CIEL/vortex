# Vortex Client 2.0 (launcher + cheat intégré)

Un seul `.exe` : au clic sur **JOUER** il installe Minecraft 1.21.11 + Fabric + Fabric API + le mod Vortex, puis **ouvre le launcher Minecraft officiel** sur un profil « Vortex Client 2.0 » (tu te connectes donc avec ton vrai compte Microsoft, rien à configurer).

Dans le jeu : **Shift droit** (modifiable dans le launcher) = menu des modules (déplaçable en glissant l'en-tête) : Fly, Speed, Sprint, AirJump, Reach, Aimbot, KillAura, AutoClicker, MacePvP, NoFall, Velocity, ESP Chest, ESP Player, ESP Enemy, Tracers, Fullbright, ChestStealer, AutoArmor, AutoTotem, AutoEat, AutoTool.

## Le lancement
Bouton **JOUER**, deux modes :

- **Launcher officiel** (par défaut) → prépare tout et ouvre le launcher Minecraft officiel. Choisis le profil **Vortex Client 2.0** puis JOUER. C'est le launcher officiel qui gère le compte (premium), donc pas de client ID Azure, pas de mot de passe stocké par le client.
  - Minecraft / Fabric / les mods sont installés dans `%APPDATA%\.minecraft` (version + profil) et le dossier de jeu du profil pointe sur `%APPDATA%\.vortex` (mods, options, saves).
  - Le profil est (re)créé automatiquement à chaque clic sur JOUER.
- **Direct (hors-ligne)** → l'ancien comportement : le launcher télécharge son propre Java + Minecraft dans `%APPDATA%\.vortex`, connecte le pseudo hors-ligne et lance le jeu directement (serveurs `online-mode=false`). Le champ « Serveur à rejoindre » ne sert que dans ce mode.

## Modules
| Catégorie | Module | Effet |
|---|---|---|
| Mouvement | Fly | vol libre (~11 blocs/s) avec anti-kick : une micro-descente toutes les 1,5 s remet à zéro le compteur « en l'air » du serveur |
| Mouvement | **Speed** | speedhack au sol (~13 blocs/s), +15 % en sprint, **conserve l'élan en l'air**, et se désactive tout seul quand Fly est actif |
| Mouvement | Sprint | sprint forcé dès qu'on avance, même avec peu de faim (action vanilla, indétectable) |
| Mouvement | AirJump | saut supplémentaire en l'air (impulsion verticale réglable) |
| Combat | Reach | portée d'attaque **3.2** au lieu de 3.0 : assez pour toucher, sous les seuils habituels des anticheat |
| Combat | **Aimbot** | vise la cible **sous le viseur** (cône 55°), **uniquement pendant que tu maintiens le clic gauche**, avec prédiction du déplacement, verrouillage de cible (350 ms anti-zapping) et rotation lissée — la caméra reste libre quand tu ne frappes pas |
| Combat | **KillAura** | frappe auto avec **rotation vers la cible**, portée réelle du joueur, cooldown vanilla ≥ 95 % et CPS plafonné : plus de coups à dégâts nuls qui rendaient le PvP injouable |
| Combat | AutoClicker | clique auto sur l'entité sous le viseur quand tu maintiens le clic gauche |
| Combat | **MacePvP** | **PvP mace 100 % auto** : cible indépendante du cône Aimbot, wind charge main/secondaire avec synchro du slot, visée prédictive, approche, saut critique et smash uniquement en descente |
| Combat | NoFall | envoie un paquet « au sol » pendant la chute : annule les dégâts de chute |
| Combat | Velocity | réduit fortement le recul subi (20 % par défaut, réglable) |
| Rendu | **ESP Chest** | coffres (**bleu**), barils (**orange**), coffres de l'Ender (**violet**) et shulkers (**cyan**) à travers les murs : cadre + léger remplissage, **doubles coffres fusionnés en une seule boîte**, nom et distance, et **carré de secours quand on est trop près** pour que rien ne disparaisse |
| Rendu | **ESP Player** | joueurs uniquement : **coins façon client**, nom, points de vie, distance et barre de vie, à travers les murs (portée réglable jusqu'à 256 blocs) |
| Rendu | ESP Enemy | mobs uniquement : **monstres en orange**, **animaux en jaune**, cadre + nom + PV + distance + barre de vie |
| Rendu | Tracers | ligne du bas de l'écran vers chaque joueur (100 % client, invisible pour le serveur) |
| Rendu | Fullbright | luminosité maximale de nuit et dans les grottes (change juste l'option gamma) |
| Inventaire | ChestStealer | vide le coffre ouvert avec des transferts vanilla (maj + clic), 2 ticks entre chaque stack |
| Inventaire | AutoArmor | enfile la meilleure armure de la barre rapide, et **remplace la pièce portée si elle est meilleure** |
| Inventaire | AutoTotem | remet un totem d'immortalité en main secondaire dès qu'elle est vide |
| Inventaire | AutoEat | mange automatiquement quand la faim descend sous 16 (réglable) |
| Inventaire | AutoTool | sélectionne le meilleur outil de la barre rapide pour le bloc visé |

Réglages dans `Aimbot.java` : `RANGE`, `FOV` (cône 55°), `TURN` (0.18 = lissé, 1 = instantané), `MAX_STEP` (3.5°/tick), `REACTION_MS` (140 ms), `SWITCH_MS` (350 ms entre deux cibles), `PREDICT` (1.5 tick d'avance), `AIM_HEIGHT` (0.8 = poitrine/tête), `ON_CLICK` (n'agir que clic gauche maintenu), `SEND_EVERY`, `AUTO_ATTACK` (désactivé), `WALLS`.
`KillAura.java` : `RANGE`, `CPS`, `PLAYERS_ONLY`, `WALLS`, `ROTATE` (viser avant de frapper), `CLICK_ONLY`, `CRIT`, `PREDICT`. `AutoClicker.java` : `CPS`, `HOLD`.
`ESPChest.java` : `RANGE_XZ` (128), `RANGE_Y` (64), `LABEL_FROM` (8 m), `LABELS`, `CORNERS`, `SHULKERS_ONLY`. `ESPPlayer.java` : `RANGE` (128), `SHOW_INFO`, `SHOW_BAR`, `CORNERS`. `ESPEnemy.java` : `RANGE` (96), `SHOW_INFO`. `Tracers.java` : `RANGE`, `ONLY_PLAYERS`, `COLOR`.
`Reach.java` : `REACH` (3.2). `ChestStealer.java` : `DELAY` (2 ticks). `AutoArmor.java` : `DELAY` (6 ticks), `UPGRADE`.
`MacePvP.java` : `RANGE`, `AUTO_WALK`, `WALK_SPEED`, `AUTO_JUMP`, `WIND_CHARGE`, `MIN_FALL`, `CRIT`, `WIND_COOLDOWN`, `LEAD_TICKS` (prédiction), `LAUNCH_RANGE`, `WALLS`.
`NoFall.java` : `MIN_FALL`, `INTERVAL`. `Velocity.java` : `FACTOR`, `TICKS`.
`AutoEat.java` : `THRESHOLD`, `OFFHAND`. `AutoTool.java` : `ONLY_WHILE_MINING`. `AirJump.java` : `POWER`, `COOLDOWN`.
`Fly.java` : `SPEED`, `SPRINT_MULT`, `VSPEED`, `ANTI_KICK`, `ANTI_KICK_PERIOD`. `SpeedHack.java` : `SPEED`, `AIR_SPEED`, `SPRINT_MULT`, `AUTO_JUMP`.

### Ce qui est vraiment « indétectable »
- **Invisible pour le serveur** (rendu uniquement) : Fullbright, Tracers, ESP Chest, ESP Player, ESP Enemy. Aucun paquet n'est envoyé, un anticheat ne peut rien voir.
- **Actions 100 % vanilla** : ChestStealer, AutoArmor, Sprint. Ce sont des clics/transferts normaux, juste automatisés ; seul un staff qui te regarde peut le remarquer.
- **Low profile** : Reach (3.2) et Aimbot avec `TURN < 1` restent sous les seuils de la plupart des anticheat.
- **Les plus visibles** : Fly et Speed. Ils modifient le mouvement réel ; face à Grim/Matrix/Vulcan ils finiront par être signalés. Sur le serveur d'un pote sans anticheat, aucun souci.
- Aucun client ne peut garantir l'indétectabilité : elle dépend toujours de l'anticheat installé côté serveur.

## Interface du launcher
Le launcher reprend le style « client » : barre latérale d'icônes, cartes, accent de couleur et footer `Config | Bind menu | Build`.

- **Jouer** : mode de lancement, serveur (mode Direct), mémoire allouée, bouton JOUER.
- **Modules** : coche les modules à activer **automatiquement au démarrage** du jeu.
- **Packs** : importe le dossier `mods` d'une instance CurseForge/Prism/MultiMC (bouton « Importer « pack pvp » » pour la détection auto), puis installe-le en un clic. Liste des mods installés avec **Activer / Désactiver** (renomme en `.jar.disabled`) et suppression. Les packs sont stockés dans `%APPDATA%\.vortex\packs`.
- **Téléphone** : serveur local de télécommande (port 8765, code PIN) pour piloter le client depuis un téléphone en Wi-Fi, et bouton pour copier l'**APK** sur le Bureau.
- **Compte** : connexion Microsoft et pseudo hors-ligne.
- **Dossier** : ouvre le dossier de jeu, les mods, les logs et le `config.json`.
- **Réglages** : couleur d'accent (Rouge/Bleu/Violet/Vert), sons, masquage du HUD pendant F2, **touche du menu** et **taille du menu en jeu**.
- **À propos** : version, build et limites côté client.

Tout est enregistré dans `%APPDATA%\.vortex\config.json` et lu par le mod au démarrage :
`theme`, `accent`, `menu_key` (`RSHIFT`, `RCTRL`, `INSERT`, `F6`…), `menu_size` (0.7–1.6), `sound`, `hide_on_screenshot`, `modules` (liste des modules auto-activés).

## Version téléphone (APK)

Minecraft **Java + Fabric ne peut pas tourner sur Android** : l'APK est un **écran de contrôle** du PC, pas un client Minecraft mobile.

1. Sur le PC : lance `Vortex Client.exe`, ouvre la page **Téléphone** → le serveur démarre sur le port **8765** et affiche `http://192.168.x.x:8765/?pin=XXXX`.
2. Autorise le launcher dans le pare-feu Windows (fenêtre au premier lancement).
3. Installe **`Vortex Remote.apk`** sur le téléphone (page Téléphone → « Copier l'APK sur le Bureau », puis câble/Drive).
4. Dans l'app, colle l'adresse complète (avec `?pin=`) et valide. Le téléphone doit être sur le **même Wi-Fi**.

Depuis l'app (ou le navigateur du téléphone) : activer/désactiver les 21 modules, installer un pack, activer/désactiver/supprimer un mod, et lancer le jeu.
Les modules cochés sont appliqués **au prochain lancement** du jeu (le mod lit `config.json` au démarrage).

L'APK est compilé sans Android Studio : `android\build_android.ps1` (aapt2 + javac + d8 + apksigner).
Il faut le SDK Android (`platforms;android-34`, `build-tools;34.0.0`) ; `ANDROID_SDK_ROOT` ou le dossier `%LOCALAPPDATA%\Temp\opencode\android-sdk`.

### Kick « Flying is not enabled on this server »
C'est une vérification **vanilla du serveur** : après 80 ticks (4 s) passés en l'air sans toucher le sol, il éjecte le joueur. Elle est donc présente même sur le serveur d'un pote, sans plugin.
Le module Fly envoie une micro-descente (12 cm) toutes les 1,5 s : un seul paquet avec un mouvement vers le bas remet le compteur à zéro, donc on peut rester en l'air. En plus le vol stationnaire compense maintenant la gravité (avant il descendait tout seul, ce qui poussait à maintenir Espace → montée continue → kick).

Si le kick persiste et que le message n'est **pas** « Flying is not enabled » (par ex. « moved too quickly », « Invalid movement »), c'est un **plugin anticheat** : là aucun réglage côté client ne suffit, il faut voir avec le proprio du serveur (`allow-flight=true` dans `server.properties`, retirer le module de vol de l'anticheat, ou t'ajouter en excepté).


**Limite honnête** : les dégâts et les mouvements sont calculés/validés par le serveur, un client ne peut donc pas rendre un joueur réellement immortel. `NoFall` annule les dégâts de chute, `Velocity` réduit le recul, `AutoTotem` garde un totem en main — le reste (attaques, explosions, /kill) dépend entièrement du serveur. De même, `Aimbot`, `KillAura` et `AutoClicker` envoient de vrais clics/rotations : invisibles pour un serveur sans anticheat, mais détectables par Grim/Matrix/Vulcan.

## Obtenir le .exe (sans compte, sans rien installer)
1. Dézipe ce dossier quelque part (ex. Bureau).
2. Double-clique sur **build.bat**. Il télécharge un Java 21 et Gradle *portables* dans le sous-dossier `tools` (rien n'est installé sur ton PC), compile le mod, installe Python via winget si besoin, puis crée **`Vortex Client.exe`** à la racine.
3. Lance `Vortex Client.exe`, clique JOUER. (Tu peux supprimer `tools` après.)

## Connexion Microsoft (mode Direct uniquement)
Le mode **Launcher officiel** n'en a pas besoin : c'est le launcher Minecraft qui gère le compte. C'est utile seulement si tu lances en direct.

- **Hors-ligne** : tape un pseudo. Ne marche que sur les serveurs "cracked" (online-mode=false).
- **Microsoft** (serveurs premium) : il faut un client ID Azure, mais **plus besoin de recompiler** :
  - le launcher lit l'ID dans `%APPDATA%\.vortex\config.json` (clé `client_id`), ou dans un fichier `client_id.txt` posé à côté du `.exe`, ou dans la variable d'environnement `VORTEX_CLIENT_ID` ;
  - si aucun ID n'est trouvé, clique sur **Connexion Microsoft** : le launcher explique les étapes, ouvre le portail Azure et te demande de coller l'ID (il l'enregistre tout seul).

  Créer l'application (une seule fois, gratuit) :
  1. portal.azure.com > App registrations > New registration, comptes "Personal Microsoft accounts", redirect URI (Public client) `http://localhost`.
  2. Copie l'Application (client) ID : colle-le dans la fenêtre du launcher (ou dans `client_id.txt`).
  3. Mojang exige maintenant d'approuver chaque nouvelle app pour l'API Minecraft (formulaire sur https://aka.ms/AppRegInfo), ça peut prendre quelques jours. Sans cette validation, la connexion Microsoft peut renvoyer une erreur au moment du login.

  Pendant la connexion, le navigateur revient tout seul sur `http://localhost` : une page "Connexion réussie" s'affiche, tu peux la fermer. Si le port 80 est occupé, le launcher te demande de coller l'URL finale à la main.
