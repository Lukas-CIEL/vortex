package com.vortex.remote;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Vortex Remote : écran de contrôle du launcher sur le PC.
 * L'app ne fait pas tourner Minecraft (Java/Fabric n'existe pas sur Android),
 * elle se connecte au serveur local du launcher et pilote modules / packs / lancement.
 */
public class MainActivity extends Activity
        implements android.view.View.OnClickListener, android.widget.TextView.OnEditorActionListener {

    private static final String PREFS = "vortex";
    private static final String KEY_URL = "url";
    private static final int BG = 0xFF08080C;
    private static final int BAR = 0xFF0C0C13;
    private static final int CARD = 0xFF14141E;
    private static final int TEXT = 0xFFE8EAF3;
    private static final int MUTED = 0xFF878CA3;
    private static final int RED = 0xFFEF4444;

    private WebView web;
    private EditText input;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(10), dp(10), dp(10));
        bar.setBackgroundColor(BAR);

        TextView logo = new TextView(this);
        logo.setText("V");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(17);
        logo.setGravity(Gravity.CENTER);
        logo.setBackgroundColor(RED);
        bar.addView(logo, new LinearLayout.LayoutParams(dp(34), dp(34)));

        input = new EditText(this);
        input.setHint("http://192.168.1.10:8765/?pin=1234");
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setTextSize(12);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_GO);
        input.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        input.setBackgroundColor(CARD);
        input.setPadding(dp(10), 0, dp(10), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        lp.setMargins(dp(10), 0, dp(8), 0);
        bar.addView(input, lp);

        Button ok = new Button(this);
        ok.setText("OK");
        ok.setTextColor(Color.WHITE);
        ok.setBackgroundColor(RED);
        ok.setOnClickListener(this);
        bar.addView(ok, new LinearLayout.LayoutParams(dp(56), dp(38)));
        root.addView(bar);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setBackgroundColor(BG);
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        input.setOnEditorActionListener(this);

        String saved = prefs.getString(KEY_URL, "");
        if (saved != null && !saved.isEmpty()) {
            input.setText(saved);
            web.loadUrl(saved);
        } else {
            web.loadDataWithBaseURL(null, helpHtml(), "text/html", "utf-8", null);
        }
    }

    private void connect() {
        String u = input.getText().toString().trim();
        if (u.isEmpty()) {
            return;
        }
        if (!u.startsWith("http://") && !u.startsWith("https://")) {
            u = "http://" + u;
        }
        prefs.edit().putString(KEY_URL, u).apply();
        web.loadUrl(u);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(android.view.View v) {
        connect();
    }

    @Override
    public boolean onEditorAction(android.widget.TextView v, int action, android.view.KeyEvent ev) {
        if (action == EditorInfo.IME_ACTION_GO) {
            connect();
            return true;
        }
        return false;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private String helpHtml() {
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{background:#08080C;color:#E8EAF3;font-family:sans-serif;padding:22px;line-height:1.55}"
                + "h1{font-size:20px;margin:0 0 4px}span{color:#EF4444}.c{background:#14141E;border:1px solid #232331;"
                + "border-radius:16px;padding:16px;margin-top:16px;font-size:14px}"
                + "b{color:#fff}.m{color:#878CA3;font-size:12px}</style></head><body>"
                + "<h1>Vortex <span>Remote</span></h1>"
                + "<div class='m'>Écran de contrôle du PC</div>"
                + "<div class='c'><b>1.</b> Sur le PC, lance <b>Vortex Client 2.0</b>.<br>"
                + "<b>2.</b> Ouvre la page <b>Téléphone</b> : le serveur démarre et affiche une adresse du type "
                + "<b>http://192.168.x.x:8765/?pin=1234</b>.<br>"
                + "<b>3.</b> Le téléphone doit être sur le <b>même Wi-Fi</b>.<br>"
                + "<b>4.</b> Colle l'adresse complète (avec le <b>?pin=</b>) dans la barre en haut, puis OK.</div>"
                + "<div class='c m'>Si la page ne charge pas : autorise le launcher dans le pare-feu Windows, "
                + "et vérifie que le PC et le téléphone sont sur le même réseau.</div>"
                + "</body></html>";
    }
}
