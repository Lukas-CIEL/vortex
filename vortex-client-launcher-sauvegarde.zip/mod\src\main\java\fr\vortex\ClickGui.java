package fr.vortex;

import fr.vortex.modules.*;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Menu en jeu façon « client moderne » (Vape-like) :
 * panneau arrondi, onglets par catégorie, liste de modules avec interrupteurs,
 * panneau de réglages à droite avec sliders.
 */
public class ClickGui extends Screen {

    // ---------------------------------------------------------------- données
    private static final String[] TABS = {"COMBAT", "MOUVEMENT", "RENDU", "INVENTAIRE"};

    private static final Map<String, Integer> CATEGORY = new HashMap<>();
    private static final Map<String, String> DESC = new HashMap<>();
    private static final Map<String, List<Slider>> SLIDERS = new HashMap<>();

    static {
        for (String n : new String[]{"Reach", "Aimbot", "MacePvP", "KillAura",
                                     "AutoClicker", "NoFall", "Velocity"})
            CATEGORY.put(n, 0);
        for (String n : new String[]{"Fly", "Speed", "Sprint", "AirJump"})
            CATEGORY.put(n, 1);
        for (String n : new String[]{"ESP Chest", "ESP Player", "ESP Enemy", "Tracers", "Fullbright"})
            CATEGORY.put(n, 2);
        for (String n : new String[]{"ChestStealer", "AutoArmor", "AutoTotem", "AutoEat", "AutoTool"})
            CATEGORY.put(n, 3);

        DESC.put("Fly", "Vol libre avec anti-kick serveur.");
        DESC.put("Speed", "Accélère au sol et garde l'élan en l'air.");
        DESC.put("Sprint", "Sprint permanent, même avec peu de faim.");
        DESC.put("Reach", "Portée d'attaque légèrement augmentée.");
        DESC.put("KillAura", "Frappe auto, cooldown vanilla respecté.");
        DESC.put("AutoClicker", "Clique auto sur l'entité visée (cooldown vanilla).");
        DESC.put("NoFall", "Annule les dégâts de chute.");
        DESC.put("Velocity", "Réduit fortement le recul subi.");
        DESC.put("AutoTotem", "Garde un totem en main secondaire.");
        DESC.put("AutoEat", "Mange automatiquement quand la faim baisse.");
        DESC.put("AutoTool", "Prend le meilleur outil pour le bloc visé.");
        DESC.put("AirJump", "Saut supplémentaire en l'air.");
        DESC.put("Aimbot", "Vise pendant l'attaque, avec prédiction.");
        DESC.put("MacePvP", "Combo mace automatique : wind charge + smash.");
        DESC.put("ESP Chest", "Coffres, barils, ender et shulkers : couleurs + distances.");
        DESC.put("ESP Player", "Joueurs : cadre, PV et distance.");
        DESC.put("ESP Enemy", "Mobs : monstres en orange, animaux en jaune.");
        DESC.put("Tracers", "Ligne vers chaque joueur.");
        DESC.put("Fullbright", "Luminosité maximale (gamma).");
        DESC.put("ChestStealer", "Vide le coffre ouvert (clics vanilla).");
        DESC.put("AutoArmor", "Enfile la meilleure armure disponible.");

        add("Speed", "Vitesse", 0.20, 1.20, () -> SpeedHack.SPEED, v -> SpeedHack.SPEED = v);
        add("Speed", "Vitesse air", 0.10, 1.00, () -> SpeedHack.AIR_SPEED, v -> SpeedHack.AIR_SPEED = v);
        add("Fly", "Vitesse", 0.10, 1.50, () -> Fly.SPEED, v -> Fly.SPEED = v);
        add("Fly", "Vertical", 0.10, 1.00, () -> Fly.VSPEED, v -> Fly.VSPEED = v);
        add("Reach", "Portée", 3.00, 5.00, () -> Reach.REACH, v -> Reach.REACH = v);
        add("Aimbot", "Portée", 3.00, 6.00, () -> Aimbot.RANGE, v -> Aimbot.RANGE = v);
        add("Aimbot", "Douceur", 0.05, 1.00, () -> Aimbot.TURN, v -> Aimbot.TURN = (float) v);
        add("Aimbot", "Cône FOV", 15, 120, () -> Aimbot.FOV, v -> Aimbot.FOV = v);
        addInt("Aimbot", "Réaction ms", 0, 600, () -> Aimbot.REACTION_MS, v -> Aimbot.REACTION_MS = (int) v);
        addInt("Aimbot", "Changement ms", 0, 800, () -> Aimbot.SWITCH_MS, v -> Aimbot.SWITCH_MS = (int) v);
        add("Aimbot", "Prédiction", 0.00, 4.00, () -> Aimbot.PREDICT, v -> Aimbot.PREDICT = v);
        add("Aimbot", "Hauteur visée", 0.00, 1.00, () -> Aimbot.AIM_HEIGHT, v -> Aimbot.AIM_HEIGHT = v);
        add("MacePvP", "Portée", 3.00, 8.00, () -> MacePvP.RANGE, v -> MacePvP.RANGE = v);
        add("MacePvP", "Chute mini", 0.50, 3.00, () -> MacePvP.MIN_FALL, v -> MacePvP.MIN_FALL = v);
        add("MacePvP", "Décollage", 2.50, 6.00, () -> MacePvP.LAUNCH_RANGE, v -> MacePvP.LAUNCH_RANGE = v);
        add("MacePvP", "Prédiction", 0.00, 6.00, () -> MacePvP.LEAD_TICKS, v -> MacePvP.LEAD_TICKS = v);
        add("MacePvP", "Vitesse", 0.15, 0.35, () -> MacePvP.WALK_SPEED, v -> MacePvP.WALK_SPEED = v);
        addInt("MacePvP", "Cooldown", 10, 60, () -> MacePvP.WIND_COOLDOWN, v -> MacePvP.WIND_COOLDOWN = (int) v);
        addInt("ESP Chest", "Rayon XZ", 32, 192, () -> ESPChest.RANGE_XZ, v -> ESPChest.RANGE_XZ = (int) v);
        addInt("ESP Chest", "Hauteur", 16, 128, () -> ESPChest.RANGE_Y, v -> ESPChest.RANGE_Y = (int) v);
        addInt("ESP Chest", "Labels dès", 0, 64, () -> ESPChest.LABEL_FROM, v -> ESPChest.LABEL_FROM = (int) v);
        addInt("ESP Enemy", "Portée", 32, 256, () -> ESPEnemy.RANGE, v -> ESPEnemy.RANGE = (int) v);
        addInt("ESP Player", "Portée", 32, 256, () -> ESPPlayer.RANGE, v -> ESPPlayer.RANGE = (int) v);
        addInt("Tracers", "Portée", 32, 256, () -> Tracers.RANGE, v -> Tracers.RANGE = (int) v);
        add("KillAura", "Portée", 2.50, 5.00, () -> KillAura.RANGE, v -> KillAura.RANGE = v);
        addInt("KillAura", "CPS", 2, 16, () -> KillAura.CPS, v -> KillAura.CPS = (int) v);
        add("KillAura", "Prédiction", 0.00, 3.00, () -> KillAura.PREDICT, v -> KillAura.PREDICT = v);
        addInt("AutoClicker", "CPS", 2, 20, () -> AutoClicker.CPS, v -> AutoClicker.CPS = (int) v);
        add("NoFall", "Chute mini", 1.00, 8.00, () -> NoFall.MIN_FALL, v -> NoFall.MIN_FALL = v);
        addInt("NoFall", "Intervalle", 2, 20, () -> NoFall.INTERVAL, v -> NoFall.INTERVAL = (int) v);
        add("Velocity", "Recul", 0.00, 1.00, () -> Velocity.FACTOR, v -> Velocity.FACTOR = v);
        addInt("AutoEat", "Faim mini", 4, 19, () -> AutoEat.THRESHOLD, v -> AutoEat.THRESHOLD = (int) v);
        add("AirJump", "Puissance", 0.20, 0.80, () -> AirJump.POWER, v -> AirJump.POWER = v);
        addInt("AirJump", "Cooldown", 1, 20, () -> AirJump.COOLDOWN, v -> AirJump.COOLDOWN = (int) v);
        addInt("AutoArmor", "Délai", 1, 20, () -> AutoArmor.DELAY, v -> AutoArmor.DELAY = (int) v);
        addInt("ChestStealer", "Délai", 1, 10, () -> ChestStealer.DELAY, v -> ChestStealer.DELAY = (int) v);
        add("Fullbright", "Gamma", 2.00, 20.00, () -> Fullbright.GAMMA, v -> Fullbright.GAMMA = v);
    }

    private static void add(String module, String label, double min, double max,
                            java.util.function.DoubleSupplier get, java.util.function.DoubleConsumer set) {
        SLIDERS.computeIfAbsent(module, k -> new ArrayList<>())
               .add(new Slider(label, min, max, false, get, set));
    }

    private static void addInt(String module, String label, int min, int max,
                               java.util.function.IntSupplier get, java.util.function.IntConsumer set) {
        SLIDERS.computeIfAbsent(module, k -> new ArrayList<>())
               .add(new Slider(label, min, max, true, () -> get.getAsInt(), v -> set.accept((int) Math.round(v))));
    }

    // ---------------------------------------------------------------- état
    /** Opacité du panneau : 1 = opaque, 0.5 = très transparent. */
    public static float OPACITY = 0.84f;

    private int tabIndex;
    private double scroll;
    private Hack selected;
    private SliderHit dragging;
    private final long openedAt = System.currentTimeMillis();

    // position du panneau (mémorisée pendant la session) et déplacement
    private static int panelX = Integer.MIN_VALUE;
    private static int panelY = Integer.MIN_VALUE;
    private boolean moving;
    private int moveDX, moveDY;

    private static int panelW() { return Math.round(400 * Config.menuScale); }
    private static int panelH() { return Math.round(252 * Config.menuScale); }

    private final List<RowHit> rowHits = new ArrayList<>();
    private final List<RowHit> toggleHits = new ArrayList<>();
    private final List<Rect> tabHits = new ArrayList<>();
    private final List<SliderHit> sliderHits = new ArrayList<>();
    private int closeX1, closeY1, closeX2, closeY2;
    private int listX, listY, listX2, listY2;

    public ClickGui() { super(Text.literal("Vortex 2.0")); }

    @Override public boolean shouldPause() { return false; }

    // ---------------------------------------------------------------- rendu
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        var tr = textRenderer;
        int accent = Config.accent;
        float s = Config.menuScale;

        int W = panelW(), H = panelH();
        if (panelX == Integer.MIN_VALUE) {
            panelX = (width - W) / 2;
            panelY = (height - H) / 2;
        }
        panelX = Math.max(2, Math.min(Math.max(2, width - W - 2), panelX));
        panelY = Math.max(2, Math.min(Math.max(2, height - H - 2), panelY));
        int x0 = panelX, y0 = panelY;
        int pad = Math.round(10 * s);
        int headH = Math.round(30 * s);
        int tabH = Math.round(24 * s);

        c.fill(0, 0, width, height, 0x4A000000);
        Ui.roundRect(c, x0 - 2, y0 + 5, x0 + W + 2, y0 + H + 7, Math.round(13 * s), 0x55000000);
        Ui.panel(c, x0, y0, x0 + W, y0 + H, Math.round(11 * s),
                 Ui.withAlpha(0xFF141419, OPACITY), 0xFF2A2A36);

        // en-tête
        int barW = Math.max(3, Math.round(3 * s));
        Ui.roundRect(c, x0 + pad, y0 + Math.round(10 * s),
                     x0 + pad + barW, y0 + headH - Math.round(9 * s), barW / 2, accent);
        int titleX = x0 + pad + barW + Math.round(8 * s);
        int titleY = y0 + Math.round(12 * s);
        c.drawTextWithShadow(tr, "VORTEX", titleX, titleY, 0xFFFFFFFF);
        c.drawTextWithShadow(tr, "2.0", titleX + tr.getWidth("VORTEX") + 3, titleY, accent);

        int cs = Math.round(15 * s);
        closeX1 = x0 + W - pad - cs;
        closeY1 = y0 + Math.round(10 * s);
        closeX2 = closeX1 + cs;
        closeY2 = closeY1 + cs;
        boolean hovClose = Ui.inside(mx, my, closeX1, closeY1, closeX2, closeY2);
        if (hovClose) Ui.roundRect(c, closeX1, closeY1, closeX2, closeY2, Math.round(4 * s), 0x50EF4444);
        Ui.text(c, tr, "x", closeX1 + cs / 2 - tr.getWidth("x") / 2, closeY1 + Math.max(1, (cs - 9) / 2),
                hovClose ? 0xFFEF4444 : 0xFF878CA3);

        // onglets
        int tabY = y0 + headH;
        int tabsX = x0 + pad, tabsW = W - pad * 2;
        int cellW = tabsW / TABS.length;
        tabHits.clear();
        for (int i = 0; i < TABS.length; i++) {
            int cx1 = tabsX + i * cellW, cx2 = cx1 + cellW;
            boolean act = i == tabIndex;
            boolean hov = Ui.inside(mx, my, cx1, tabY, cx2, tabY + tabH);
            String label = TABS[i];
            int lw = tr.getWidth(label);
            int lx = cx1 + (cellW - lw) / 2;
            int ly = tabY + (tabH - 9) / 2;
            Ui.text(c, tr, label, lx, ly, act ? 0xFFFFFFFF : hov ? 0xFFC9CCDA : 0xFF878CA3);
            if (act) {
                int uw = lw + Math.round(10 * s);
                Ui.roundRect(c, cx1 + (cellW - uw) / 2, tabY + tabH - Math.max(2, Math.round(3 * s)),
                             cx1 + (cellW + uw) / 2, tabY + tabH, 2, accent);
            }
            tabHits.add(new Rect(cx1, tabY, cx2, tabY + tabH));
        }
        c.fill(tabsX, tabY + tabH, x0 + W - pad, tabY + tabH + 1, 0xFF232330);

        // contenu
        int contentY = tabY + tabH + Math.round(9 * s);
        int contentY2 = y0 + H - pad;
        listX = x0 + pad;
        listY = contentY;
        listX2 = listX + (int) Math.round((W - pad * 2) * 0.55);
        listY2 = contentY2;
        Ui.panel(c, listX, listY, listX2, listY2, Math.round(8 * s),
                 Ui.withAlpha(0xFF101015, OPACITY * 0.95f), 0xFF232330);

        List<Hack> mods = modulesInTab();
        int rowH = Math.round(23 * s), gap = Math.round(2 * s), inset = Math.round(6 * s);
        int rowX1 = listX + inset, rowX2 = listX2 - inset;
        int innerH = (listY2 - listY) - inset * 2;
        int totalH = mods.size() * (rowH + gap);
        double maxScroll = Math.max(0, totalH - innerH);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        rowHits.clear();
        toggleHits.clear();
        c.enableScissor(listX + 1, listY + 1, listX2 - 1, listY2 - 1);
        for (int i = 0; i < mods.size(); i++) {
            Hack m = mods.get(i);
            int ry = listY + inset + i * (rowH + gap) - (int) scroll;
            if (ry + rowH < listY || ry > listY2) continue;
            boolean hov = Ui.inside(mx, my, rowX1, ry, rowX2, ry + rowH)
                          && my > listY && my < listY2;
            int bg = m.enabled ? Ui.withAlpha(accent, hov ? 0.30f : 0.17f)
                               : (hov ? Ui.withAlpha(0xFF1A1A23, 0.92f) : 0x00000000);
            if ((bg >>> 24) != 0) Ui.roundRect(c, rowX1, ry, rowX2, ry + rowH, Math.round(5 * s), bg);
            if (m.enabled) {
                Ui.roundRect(c, rowX1, ry + Math.round(5 * s), rowX1 + 2,
                             ry + rowH - Math.round(5 * s), 1, accent);
            }
            Ui.text(c, tr, m.name, rowX1 + Math.round(9 * s), ry + (rowH - 9) / 2,
                    m.enabled ? 0xFFFFFFFF : 0xFFB9BDCB);

            int tw = Math.round(26 * s), th = Math.max(10, Math.round(13 * s));
            int tx1 = rowX2 - Math.round(8 * s) - tw, ty1 = ry + (rowH - th) / 2;
            Ui.roundRect(c, tx1, ty1, tx1 + tw, ty1 + th, th / 2,
                         m.enabled ? accent : Ui.withAlpha(0xFF2C2C38, 0.96f));
            int kr = Math.max(2, th / 2 - 2);
            int kx = m.enabled ? tx1 + tw - th / 2 : tx1 + th / 2;
            Ui.circle(c, kx, ty1 + th / 2, kr, m.enabled ? 0xFFFFFFFF : 0xFF9A9EB0);

            rowHits.add(new RowHit(m, new Rect(rowX1, ry, rowX2, ry + rowH)));
            toggleHits.add(new RowHit(m, new Rect(tx1, ty1 - 2, tx1 + tw, ty1 + th + 2)));
        }
        c.disableScissor();

        // panneau de réglages
        int setX = listX2 + Math.round(10 * s);
        int setX2 = x0 + W - pad;
        Ui.panel(c, setX, listY, setX2, listY2, Math.round(8 * s),
                 Ui.withAlpha(0xFF101015, OPACITY * 0.95f), 0xFF232330);
        sliderHits.clear();

        if (selected == null || !mods.contains(selected)) selected = mods.isEmpty() ? null : mods.get(0);
        int sx = setX + Math.round(10 * s);
        int sx2 = setX2 - Math.round(10 * s);
        int sw = sx2 - sx;
        if (selected == null) {
            Ui.text(c, tr, "Aucun module", sx, listY + 12, 0xFF878CA3);
        } else {
            int sy = listY + Math.round(10 * s);
            Ui.text(c, tr, selected.name, sx, sy, 0xFFFFFFFF);
            String state = selected.enabled ? "ACTIF" : "INACTIF";
            int pw = tr.getWidth(state) + 10;
            Ui.roundRect(c, sx2 - pw, sy - 1, sx2, sy + 10, 4,
                         selected.enabled ? Ui.withAlpha(accent, 0.95f) : 0xFF232330);
            Ui.text(c, tr, state, sx2 - pw + 5, sy, selected.enabled ? 0xFFFFFFFF : 0xFF878CA3);
            sy += 15;

            String desc = DESC.getOrDefault(selected.name, "");
            for (OrderedText line : tr.wrapLines(Text.literal(desc), sw)) {
                if (sy > listY2 - 12) break;
                c.drawText(tr, line, sx, sy, 0xFF878CA3, false);
                sy += 10;
            }
            sy += 4;

            for (Slider sl : SLIDERS.getOrDefault(selected.name, List.of())) {
                if (sy + 20 > listY2 - 4) break;
                Ui.text(c, tr, sl.label, sx, sy, 0xFFB9BDCB);
                String val = sl.format();
                Ui.text(c, tr, val, sx2 - tr.getWidth(val), sy, 0xFFE8EAF3);
                int trackY = sy + 11;
                Ui.roundRect(c, sx, trackY, sx2, trackY + 3, 2, 0xFF232330);
                double t = (sl.get.getAsDouble() - sl.min) / (sl.max - sl.min);
                t = Math.max(0, Math.min(1, t));
                int fill = (int) Math.round((sx2 - sx) * t);
                if (fill > 0) Ui.roundRect(c, sx, trackY, sx + Math.max(fill, 3), trackY + 3, 2, accent);
                Ui.circle(c, sx + fill, trackY + 1, 3, 0xFFFFFFFF);
                sliderHits.add(new SliderHit(sl, new Rect(sx, trackY - 6, sx2, trackY + 9)));
                sy += 22;
            }
        }

        // pied de page
        Ui.text(c, tr, "glisser l'en-tête pour déplacer  ·  ESC fermer", x0 + pad,
                y0 + H - Math.round(9 * s), 0xFF5B6070);
    }

    private List<Hack> modulesInTab() {
        List<Hack> list = new ArrayList<>();
        for (Hack m : VortexClient.modules) {
            if (CATEGORY.getOrDefault(m.name, 3) == tabIndex) list.add(m);
        }
        return list;
    }

    // ---------------------------------------------------------------- souris
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        if (Ui.inside(mx, my, closeX1, closeY1, closeX2, closeY2)) {
            close();
            return true;
        }
        // glisser l'en-tête pour déplacer la fenêtre
        if (Ui.inside(mx, my, panelX, panelY, panelX + panelW(),
                      panelY + Math.round(30 * Config.menuScale))) {
            moving = true;
            moveDX = (int) Math.round(mx - panelX);
            moveDY = (int) Math.round(my - panelY);
            return true;
        }
        for (int i = 0; i < tabHits.size(); i++) {
            if (tabHits.get(i).has(mx, my)) {
                tabIndex = i;
                scroll = 0;
                selected = null;
                return true;
            }
        }
        for (RowHit t : toggleHits) {
            if (t.r.has(mx, my)) {
                t.module.toggle();
                selected = t.module;
                return true;
            }
        }
        for (RowHit r : rowHits) {
            if (r.r.has(mx, my)) {
                selected = r.module;
                return true;
            }
        }
        for (SliderHit sh : sliderHits) {
            if (sh.r.has(mx, my)) {
                dragging = sh;
                applySlider(sh, mx);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (moving) {
            panelX = (int) Math.round(click.x() - moveDX);
            panelY = (int) Math.round(click.y() - moveDY);
            return true;
        }
        if (dragging != null) {
            applySlider(dragging, click.x());
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (moving) {
            moving = false;
            return true;
        }
        if (dragging != null) {
            dragging = null;
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (Ui.inside(mx, my, listX, listY, listX2, listY2)) {
            scroll -= vertical * 16;
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    private void applySlider(SliderHit sh, double mx) {
        double t = (mx - sh.r.x1) / (double) Math.max(1, sh.r.x2 - sh.r.x1);
        t = Math.max(0, Math.min(1, t));
        double v = sh.slider.min + t * (sh.slider.max - sh.slider.min);
        if (sh.slider.integer) v = Math.round(v);
        v = Math.max(sh.slider.min, Math.min(sh.slider.max, v));
        sh.slider.set.accept(v);
    }

    // ---------------------------------------------------------------- types
    private static final class Slider {
        final String label;
        final double min, max;
        final boolean integer;
        final java.util.function.DoubleSupplier get;
        final java.util.function.DoubleConsumer set;

        Slider(String label, double min, double max, boolean integer,
               java.util.function.DoubleSupplier get, java.util.function.DoubleConsumer set) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.integer = integer;
            this.get = get;
            this.set = set;
        }

        String format() {
            return integer ? String.valueOf((int) Math.round(get.getAsDouble()))
                           : String.format(Locale.ROOT, "%.2f", get.getAsDouble());
        }
    }

    private static final class Rect {
        final int x1, y1, x2, y2;

        Rect(int x1, int y1, int x2, int y2) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
        }

        boolean has(double mx, double my) {
            return Ui.inside(mx, my, x1, y1, x2, y2);
        }
    }

    private static final class RowHit {
        final Hack module;
        final Rect r;

        RowHit(Hack module, Rect r) {
            this.module = module;
            this.r = r;
        }
    }

    private static final class SliderHit {
        final Slider slider;
        final Rect r;

        SliderHit(Slider slider, Rect r) {
            this.slider = slider;
            this.r = r;
        }
    }
}
