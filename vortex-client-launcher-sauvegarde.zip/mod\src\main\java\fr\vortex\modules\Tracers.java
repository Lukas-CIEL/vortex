package fr.vortex.modules;
import fr.vortex.Esp;
import fr.vortex.Hack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
/**
 * Tracers : une ligne du bas de l'écran vers chaque joueur (ou entité vivante).
 * Purement visuel côté client : le serveur ne voit rien, donc indétectable.
 */
public class Tracers extends Hack {
    public static int RANGE = 128;
    public static boolean ONLY_PLAYERS = true;
    public static int COLOR = 0xFFEF4444;

    public Tracers() { super("Tracers"); }

    @Override public void onHud(DrawContext c, float td) {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
        if (ONLY_PLAYERS) {
            for (var e : mc.world.getPlayers()) {
                if (e == p) continue;
                draw(c, e, td, w, h);
            }
        } else {
            Box area = p.getBoundingBox().expand(RANGE);
            for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, area, e -> e != p))
                draw(c, e, td, w, h);
        }
    }

    private void draw(DrawContext c, LivingEntity e, float td, int w, int h) {
        Vec3d t = e.getLerpedPos(td).add(0, e.getHeight() * 0.5, 0);
        int[] s = Esp.project(t, td);
        if (s == null) return;
        if (s[0] < -2000 || s[0] > w + 2000 || s[1] < -2000 || s[1] > h + 2000) return;
        line(c, w / 2, h, s[0], s[1], COLOR);
    }

    /** Ligne 1 px via une matrice tournée (un seul fill par trait). */
    private static void line(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        int dx = x2 - x1, dy = y2 - y1;
        double len = Math.sqrt((double) dx * dx + (double) dy * dy);
        if (len < 1.0) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) x1, (float) y1);
        m.rotate((float) Math.atan2(dy, dx));
        c.fill(0, -1, (int) Math.round(len), 1, color);
        m.popMatrix();
    }
}
