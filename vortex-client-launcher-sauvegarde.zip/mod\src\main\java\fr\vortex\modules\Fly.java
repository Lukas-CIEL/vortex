package fr.vortex.modules;
import fr.vortex.Hack;
import net.minecraft.client.network.ClientPlayerEntity;
/**
 * Fly avec anti-kick, utilisable sur un serveur où allow-flight est resté à false.
 *
 * Le serveur vanilla compte les ticks passés en l'air (80 max ≈ 4 s) et kick avec
 * « Flying is not enabled on this server ». Une seule micro-descente (> 0.031 bloc
 * vers le bas dans un paquet de mouvement) remet ce compteur à zéro, donc on en
 * glisse une régulièrement pendant qu'on vole.
 */
public class Fly extends Hack {
    public static double SPEED = 0.55;        // vitesse horizontale par tick (~11 blocs/s)
    public static double SPRINT_MULT = 1.15;  // bonus en sprint
    public static double VSPEED = 0.45;       // montée / descente
    public static boolean ANTI_KICK = true;   // évite le kick "Flying is not enabled"
    public static int ANTI_KICK_PERIOD = 30;  // ticks entre deux micro-descentes (1,5 s)

    private int ticks;

    public Fly() { super("Fly"); }

    @Override public void onEnable() { ticks = 0; }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        var in = p.input.playerInput;
        float yaw = p.getYaw() * 0.017453292f;
        float f = (in.forward() ? 1 : 0) - (in.backward() ? 1 : 0);
        float s = (in.left() ? 1 : 0) - (in.right() ? 1 : 0);
        double x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double z =  Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(x * x + z * z);
        double speed = SPEED * (p.isSprinting() ? SPRINT_MULT : 1.0);
        if (len > 1e-4) { x = x / len * speed; z = z / len * speed; } else { x = 0; z = 0; }
        double y = in.jump() ? VSPEED : in.sneak() ? -VSPEED : 0.08;  // 0.08 compense la gravité
        if (ANTI_KICK && ++ticks % Math.max(1, ANTI_KICK_PERIOD) == 0) y = -0.12;  // micro-descente
        p.setVelocity(x, y, z);
        p.fallDistance = 0f;
    }
}
