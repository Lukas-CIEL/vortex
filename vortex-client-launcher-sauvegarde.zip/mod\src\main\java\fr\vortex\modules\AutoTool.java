package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;

/**
 * AutoTool : sélectionne automatiquement le meilleur outil de la barre rapide
 * pour le bloc visé (pioche / hache / pelle / hache-fer). Ne touche pas à
 * l'inventaire, seulement au slot sélectionné.
 */
public class AutoTool extends Hack {
    public static boolean ONLY_WHILE_MINING = true;

    public AutoTool() { super("AutoTool"); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit)) return;
        if (ONLY_WHILE_MINING && !mc.options.attackKey.isPressed()
                && !mc.interactionManager.isBreakingBlock()) return;

        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (state.isAir()) return;

        var inv = p.getInventory();
        int bestSlot = -1;
        float bestSpeed = 1.0f;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isEmpty()) continue;
            float speed = stack.getMiningSpeedMultiplier(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }
        if (bestSlot >= 0 && inv.getSelectedSlot() != bestSlot) inv.setSelectedSlot(bestSlot);
    }
}
