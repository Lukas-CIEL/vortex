package fr.vortex.modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
/**
 * Remet un totem d'immortalité en main secondaire dès qu'elle est vide.
 * Appelé par le module AutoTotem ; un clic maximum par tick grâce au
 * suivi de l'âge du joueur et au cooldown.
 */
public class AutoTotem {
    private static int cooldown;
    private static int lastAge = -1;

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null || mc.currentScreen != null || mc.interactionManager == null) return;
        if (p.age == lastAge) return;
        lastAge = p.age;
        if (cooldown > 0) { cooldown--; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        int found = -1;
        for (int i = 0; i < 36 && found < 0; i++)          // barre rapide en premier
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) found = i;
        if (found < 0) return;
        int slot = found < 9 ? 36 + found : found;          // index dans playerScreenHandler
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
        cooldown = 2;
    }
}
