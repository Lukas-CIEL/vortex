package fr.vortex.modules;
import fr.vortex.Hack;
/**
 * Fullbright : luminosité maximale, de nuit comme dans les grottes.
 * 100 % côté client (on ne change que l'option gamma), donc totalement indétectable.
 */
public class Fullbright extends Hack {
    public static double GAMMA = 10.0;
    private double previous = -1;

    public Fullbright() { super("Fullbright"); }

    @Override public void onEnable() {
        previous = mc.options.getGamma().getValue();
        mc.options.getGamma().setValue(GAMMA);
    }

    @Override public void onDisable() {
        if (previous >= 0) mc.options.getGamma().setValue(previous);
    }

    @Override public void onTick() {
        if (mc.options.getGamma().getValue() < GAMMA) mc.options.getGamma().setValue(GAMMA);
    }
}
