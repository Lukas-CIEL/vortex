package fr.vortex;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.lwjgl.glfw.GLFW;

import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Lit %APPDATA%\.vortex\config.json (écrit par le launcher) :
 * touche du menu, taille/couleur du menu, modules activés au démarrage,
 * masquage du HUD pendant une capture (F2).
 */
public final class Config {
    public static int menuKey = GLFW.GLFW_KEY_RIGHT_SHIFT;
    public static float menuScale = 1.0f;
    public static int accent = 0xFFEF4444;
    public static boolean hideOnScreenshot = false;
    public static final Set<String> autoEnable = new HashSet<>();

    private Config() {}

    public static void load() {
        String appdata = System.getenv("APPDATA");
        Path base = (appdata != null && !appdata.isBlank())
                ? Paths.get(appdata) : Paths.get(System.getProperty("user.home"));
        Path file = base.resolve(".vortex").resolve("config.json");
        if (!Files.isRegularFile(file)) return;
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            JsonObject o = JsonParser.parseReader(reader).getAsJsonObject();
            if (o.has("menu_key")) menuKey = keyCode(o.get("menu_key").getAsString());
            if (o.has("menu_size")) {
                menuScale = Math.max(0.7f, Math.min(1.6f, o.get("menu_size").getAsFloat()));
            }
            if (o.has("accent")) accent = color(o.get("accent").getAsString());
            else if (o.has("theme")) accent = theme(o.get("theme").getAsString());
            if (o.has("hide_on_screenshot")) {
                hideOnScreenshot = o.get("hide_on_screenshot").getAsBoolean();
            }
            if (o.has("modules") && o.get("modules").isJsonArray()) {
                for (JsonElement e : o.getAsJsonArray("modules")) {
                    autoEnable.add(e.getAsString().toLowerCase(Locale.ROOT));
                }
            }
        } catch (Exception e) {
            System.out.println("[Vortex] config.json illisible : " + e);
        }
    }

    public static boolean autoEnabled(String moduleName) {
        return autoEnable.contains(moduleName.toLowerCase(Locale.ROOT));
    }

    private static int keyCode(String name) {
        return switch (name.toUpperCase(Locale.ROOT)) {
            case "RCTRL", "RIGHT_CONTROL" -> GLFW.GLFW_KEY_RIGHT_CONTROL;
            case "INSERT" -> GLFW.GLFW_KEY_INSERT;
            case "F6" -> GLFW.GLFW_KEY_F6;
            case "F7" -> GLFW.GLFW_KEY_F7;
            case "F8" -> GLFW.GLFW_KEY_F8;
            case "TAB" -> GLFW.GLFW_KEY_TAB;
            case "END" -> GLFW.GLFW_KEY_END;
            case "HOME" -> GLFW.GLFW_KEY_HOME;
            case "DELETE" -> GLFW.GLFW_KEY_DELETE;
            default -> GLFW.GLFW_KEY_RIGHT_SHIFT;
        };
    }

    private static int theme(String name) {
        return switch (name.toLowerCase(Locale.ROOT)) {
            case "bleu" -> 0xFF3B82F6;
            case "violet" -> 0xFF8B5CF6;
            case "vert" -> 0xFF22C55E;
            default -> 0xFFEF4444;
        };
    }

    private static int color(String value) {
        try {
            String v = value.trim();
            if (v.startsWith("#")) v = v.substring(1);
            if (v.length() == 6) return 0xFF000000 | Integer.parseInt(v, 16);
            if (v.length() == 8) return (int) Long.parseLong(v, 16);
        } catch (Exception ignored) {
        }
        return 0xFFEF4444;
    }
}
