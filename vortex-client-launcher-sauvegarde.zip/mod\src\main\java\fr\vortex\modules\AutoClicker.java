package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/**
 * AutoClicker : clique automatiquement sur l'entité sous le viseur quand tu
 * maintiens le clic gauche. Le cooldown vanilla est respecté, donc ça accélère
 * sans envoyer d'attaques impossibles.
 */
public class AutoClicker extends Hack {
    public static int CPS = 10;
    public static boolean HOLD = true;   // true = il faut garder le clic gauche

    private long lastClick;

    public AutoClicker() { super("AutoClicker"); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (HOLD && !mc.options.attackKey.isPressed()) return;

        long now = System.currentTimeMillis();
        if (now - lastClick < 1000L / Math.max(1, CPS)) return;
        if (p.getAttackCooldownProgress(0f) < 0.92f) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity target)) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        lastClick = now;
    }
}
