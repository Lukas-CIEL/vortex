package fr.vortex;

import net.minecraft.client.gui.DrawContext;

/**
 * Petits utilitaires de dessin pour l'interface (façon client moderne) :
 * rectangles arrondis, cercles, transparence. Tout est fait avec des fill,
 * donc aucun shader/ressource supplémentaire.
 */
public final class Ui {
    private Ui() {}

    /** Multiplie l'alpha d'une couleur ARGB. */
    public static int withAlpha(int color, float factor) {
        int a = Math.round(((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, factor)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    /** Rectangle arrondi plein. */
    public static void roundRect(DrawContext c, int x1, int y1, int x2, int y2, int r, int color) {
        if (x2 <= x1 || y2 <= y1) return;
        r = Math.max(0, Math.min(r, Math.min(x2 - x1, y2 - y1) / 2));
        if (r == 0) {
            c.fill(x1, y1, x2, y2, color);
            return;
        }
        c.fill(x1 + r, y1, x2 - r, y2, color);
        c.fill(x1, y1 + r, x1 + r, y2 - r, color);
        c.fill(x2 - r, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = (double) (r - i) - 0.5;
            int w = (int) Math.sqrt(Math.max(0, (double) r * r - dy * dy));
            c.fill(x1 + r - w, y1 + i, x1 + r + w, y1 + i + 1, color);          // haut gauche
            c.fill(x2 - r - w, y1 + i, x2 - r + w, y1 + i + 1, color);          // haut droit
            c.fill(x1 + r - w, y2 - i - 1, x1 + r + w, y2 - i, color);          // bas gauche
            c.fill(x2 - r - w, y2 - i - 1, x2 - r + w, y2 - i, color);          // bas droit
        }
    }

    /** Carte : bordure + fond. */
    public static void panel(DrawContext c, int x1, int y1, int x2, int y2, int r, int bg, int border) {
        roundRect(c, x1, y1, x2, y2, r, border);
        roundRect(c, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), bg);
    }

    /** Disque plein (utilisé pour les boutons de toggle et de slider). */
    public static void circle(DrawContext c, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int w = (int) Math.sqrt(Math.max(0, (double) r * r - (double) dy * dy));
            c.fill(cx - w, cy + dy, cx + w + 1, cy + dy + 1, color);
        }
    }

    /** Texte sans ombre (style plat). */
    public static void text(DrawContext c, net.minecraft.client.font.TextRenderer tr,
                            String s, int x, int y, int color) {
        c.drawText(tr, s, x, y, color, false);
    }

    public static boolean inside(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }
}
