package fr.vortex.modules;
import fr.vortex.Hack;
import fr.vortex.VortexClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
/**
 * SpeedHack : accélère au sol et garde l'élan en l'air (jamais plus lent que la vanilla).
 * Ne touche à rien quand Fly est actif, ni dans l'eau / en vol plané / à cheval.
 */
public class SpeedHack extends Hack {
    public static double SPEED = 0.65;        // vitesse au sol par tick (~13 blocs/s)
    public static double AIR_SPEED = 0.45;    // vitesse minimale en l'air (l'élan est conservé)
    public static double SPRINT_MULT = 1.15;  // bonus en sprint
    public static boolean AUTO_JUMP = false;  // bunny hop automatique

    public SpeedHack() { super("Speed"); }

    @Override public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (VortexClient.isEnabled("Fly")) return;               // Fly gère le déplacement
        if (p.isUsingItem() && !p.isSprinting()) return;         // ne casse pas l'arc / le manger
        if (p.isTouchingWater() || p.isGliding() || p.hasVehicle()) return;
        var in = p.input.playerInput;
        float f = (in.forward() ? 1 : 0) - (in.backward() ? 1 : 0);
        float s = (in.left() ? 1 : 0) - (in.right() ? 1 : 0);
        if (f == 0 && s == 0) return;
        float yaw = p.getYaw() * 0.017453292f;
        double x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double z =  Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(x * x + z * z);
        if (len < 1e-4) return;
        boolean ground = p.isOnGround();
        if (AUTO_JUMP && ground) p.jump();
        Vec3d v = p.getVelocity();
        double current = Math.sqrt(v.x * v.x + v.z * v.z);
        double target = ground ? SPEED : Math.max(AIR_SPEED, current);
        if (p.isSprinting()) target *= SPRINT_MULT;
        p.setVelocity(x / len * target, v.y, z / len * target);
        if (ground) p.fallDistance = 0;
    }
}
