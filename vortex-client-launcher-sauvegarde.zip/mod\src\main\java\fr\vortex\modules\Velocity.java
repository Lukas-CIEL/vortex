package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.util.math.Vec3d;

/**
 * Velocity (anti-knockback) : réduit le recul subi quand on est frappé.
 * FACTOR = 0 supprime tout le recul horizontal, 1 le laisse intact.
 */
public class Velocity extends Hack {
    public static double FACTOR = 0.20;
    public static int TICKS = 10;

    private int hurtTicks;

    public Velocity() { super("Velocity"); }

    @Override public void onEnable() { hurtTicks = 0; }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (p.hurtTime > 0) hurtTicks = TICKS;
        if (hurtTicks > 0) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x * FACTOR, v.y, v.z * FACTOR);
            hurtTicks--;
        }
    }
}
