"""Vortex Client 2.0 - launcher Minecraft avec le cheat intégré (Fabric 1.21.11)."""
import json, os, random, shutil, socket, socketserver, subprocess, sys, threading, time, uuid, webbrowser
import urllib.parse, urllib.request
import tkinter as tk
from tkinter import filedialog, messagebox
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import customtkinter as ctk
import minecraft_launcher_lib as mll

MC_VERSION = "1.21.11"
CLIENT_ID = "VOTRE_CLIENT_ID_AZURE"      # valeur de secours, voir README (connexion Microsoft)
REDIRECT_URL = "http://localhost"
LOGIN_TIMEOUT = 300                      # secondes d'attente de la connexion navigateur
ROOT = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), ".vortex")
CONFIG = os.path.join(ROOT, "config.json")
MC_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), ".minecraft")
GAME_DIR = ROOT                          # dossier de jeu utilisé par le profil du launcher officiel
MODS_DIR = os.path.join(ROOT, "mods")    # mods chargés par Fabric
PACKS_DIR = os.path.join(ROOT, "packs")  # packs de mods importés (un dossier = un pack)
REMOTE_PORT = 8765                       # serveur de la télécommande téléphone
APK_NAME = "Vortex Remote.apk"
PROFILE_KEY = "vortex-client-2.0"

# ---------- palette ----------
BG = "#08080C"          # fond de la fenêtre
SIDEBAR = "#0C0C13"     # barre latérale
PANEL = "#101018"       # header / footer
CARD = "#14141E"        # cartes
CARD_2 = "#1B1B27"      # éléments dans les cartes
BORDER = "#232331"
TEXT = "#E8EAF3"
MUTED = "#878CA3"
RED = "#EF4444"
BLUE = "#3B82F6"
FONT = "Segoe UI"

THEMES = {
    "Rouge": ("#EF4444", "#B91C1C"),
    "Bleu": ("#3B82F6", "#2563EB"),
    "Violet": ("#8B5CF6", "#7C3AED"),
    "Vert": ("#22C55E", "#16A34A"),
}

# noms exacts des modules du mod (voir fr/vortex/VortexClient.java)
MODULES = [
    ("Fly", "Mouvement · vol libre avec anti-kick"),
    ("Speed", "Mouvement · speedhack au sol, élan conservé"),
    ("Sprint", "Mouvement · sprint forcé, même avec peu de faim"),
    ("AirJump", "Mouvement · saut supplémentaire en l'air"),
    ("Reach", "Combat · portée 3.2 au lieu de 3.0 (discret)"),
    ("Aimbot", "Combat · visée assistée pendant l'attaque (prédiction, lissage)"),
    ("KillAura", "Combat · frappe auto avec rotation, cooldown vanilla et portée réelle"),
    ("AutoClicker", "Combat · clic auto sur l'entité visée"),
    ("MacePvP", "Combat · PvP mace 100 % auto (wind charge + smash + prédiction)"),
    ("NoFall", "Combat · annule les dégâts de chute"),
    ("Velocity", "Combat · réduit fortement le recul subi"),
    ("ESP Chest", "Rendu · coffres, barils, ender et shulkers : couleurs, distances, doubles fusionnés"),
    ("ESP Player", "Rendu · joueurs : coins, PV, distance à travers les murs"),
    ("ESP Enemy", "Rendu · mobs : monstres orange, animaux jaunes"),
    ("Tracers", "Rendu · lignes vers les joueurs (100 % client)"),
    ("Fullbright", "Rendu · luminosité max, indétectable"),
    ("ChestStealer", "Inventaire · vide le coffre ouvert (clics vanilla)"),
    ("AutoArmor", "Inventaire · enfile l'armure de la barre rapide"),
    ("AutoTotem", "Inventaire · garde un totem en main secondaire"),
    ("AutoEat", "Inventaire · mange auto quand la faim baisse"),
    ("AutoTool", "Inventaire · meilleur outil pour le bloc visé"),
]

BINDS = ["RSHIFT", "RCTRL", "INSERT", "F6", "F7", "F8", "TAB", "END", "HOME", "DELETE"]

MOBILE_HTML = r"""<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#08080C"><title>Vortex Remote</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:#08080C;color:#E8EAF3;font-family:-apple-system,'Segoe UI',Roboto,sans-serif;padding:16px 14px 40px}
header{display:flex;align-items:center;gap:10px;margin-bottom:14px}
.logo{width:42px;height:42px;border-radius:12px;background:linear-gradient(145deg,#EF4444,#7F1D1D);display:grid;place-items:center;font-weight:800;font-size:20px;color:#fff}
h1{font-size:19px;margin:0}
.sub{font-size:11px;color:#878CA3}
.card{background:#14141E;border:1px solid #232331;border-radius:16px;padding:14px;margin-bottom:12px}
.card h2{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:#878CA3;margin:0 0 8px}
.row{display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid #1E1E2A}
.row:last-child{border-bottom:0}
.n{font-size:13px}.d{font-size:10px;color:#878CA3;margin-top:2px}
.tg{width:52px;height:30px;border-radius:15px;background:#232331;position:relative;transition:.15s;flex:none;border:0;padding:0}
.tg:after{content:'';position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#878CA3;transition:.15s}
.tg.on{background:#EF4444}.tg.on:after{left:25px;background:#fff}
.play{width:100%;height:56px;border:0;border-radius:16px;background:linear-gradient(145deg,#EF4444,#B91C1C);color:#fff;font-size:18px;font-weight:800;letter-spacing:.04em;margin:2px 0 12px}
.small{font-size:11px;color:#878CA3;line-height:1.5}
.btn{border:1px solid #232331;background:#1B1B27;color:#E8EAF3;border-radius:10px;padding:8px 12px;font-size:12px}
.btn.red{border-color:#EF4444;color:#EF4444}
.pill{display:inline-block;padding:3px 8px;border-radius:999px;background:#1B1B27;font-size:10px;color:#878CA3;margin-left:6px}
.toast{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);background:#1B1B27;border:1px solid #232331;color:#E8EAF3;padding:10px 16px;border-radius:12px;font-size:12px;opacity:0;transition:.2s;pointer-events:none}
.toast.show{opacity:1}
</style></head><body>
<header><div class="logo">V</div><div><h1>Vortex <span style="color:#EF4444">Remote</span></h1><div class="sub" id="host">connexion…</div></div></header>
<button class="play" id="play">&#9654;&nbsp; JOUER</button>
<div class="card"><h2>Modules</h2><div id="mods"></div></div>
<div class="card"><h2>Packs <span class="pill" id="pcount"></span></h2><div id="packs"></div></div>
<div class="card"><h2>Mods installés</h2><div id="files"></div></div>
<div class="small">Les modules activés ici sont appliqués au prochain lancement du jeu.
Le PC doit rester allumé et le launcher ouvert.</div>
<div class="toast" id="toast"></div>
<script>
const PIN = new URLSearchParams(location.search).get('pin') || '';
const $ = s => document.querySelector(s);
let toastT;
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove('show'),1800);}
function api(p,post){return fetch(p+(p.includes('?')?'&':'?')+'pin='+encodeURIComponent(PIN),{method:post?'POST':'GET'}).then(r=>r.json());}
function el(t,c,x){const e=document.createElement(t);if(c)e.className=c;if(x!==undefined)e.textContent=x;return e;}
function render(s){
  window.STATE=s;
  $('#host').textContent=s.host||'PC connecté';
  const box=$('#mods');box.innerHTML='';
  s.modules.forEach(m=>{
    const row=el('div','row'),w=el('div');w.style.flex='1';
    w.appendChild(el('div','n',m.name));w.appendChild(el('div','d',m.desc||''));
    const t=el('button','tg'+(m.on?' on':''));
    t.onclick=()=>toggleMod(m);
    row.appendChild(w);row.appendChild(t);box.appendChild(row);
  });
  const pb=$('#packs');pb.innerHTML='';
  $('#pcount').textContent=s.packs.length+' pack'+(s.packs.length>1?'s':'');
  if(!s.packs.length){pb.appendChild(el('div','small','Aucun pack importé sur le PC.'));}
  s.packs.forEach(p=>{
    const row=el('div','row'),w=el('div');w.style.flex='1';
    w.appendChild(el('div','n',p.name));w.appendChild(el('div','d',p.count+' mods'));
    const b=el('button','btn','Installer');b.onclick=()=>installPack(p.name);
    row.appendChild(w);row.appendChild(b);pb.appendChild(row);
  });
  const fb=$('#files');fb.innerHTML='';
  if(!s.mods.length){fb.appendChild(el('div','small','Aucun mod installé.'));}
  s.mods.forEach(m=>{
    const row=el('div','row'),w=el('div');w.style.flex='1';
    w.appendChild(el('div','n',m.name));
    w.appendChild(el('div','d',m.size.toFixed(1)+' Mo'+(m.disabled?' · désactivé':'')));
    const t=el('button','btn',m.disabled?'Activer':'Désactiver');t.onclick=()=>toggleFile(m.name);
    const del=el('button','btn red','Suppr');del.onclick=()=>deleteFile(m.name);
    del.style.marginLeft='6px';
    row.appendChild(w);row.appendChild(t);row.appendChild(del);fb.appendChild(row);
  });
}
async function toggleMod(m){
  const s=await api('/api/module?name='+encodeURIComponent(m.name)+'&on='+(m.on?0:1),true);
  if(!s.ok){toast('Erreur');return;}
  render(s);toast(m.name+(m.on?' désactivé':' activé'));
}
async function installPack(n){
  toast('Installation…');
  const s=await api('/api/pack?name='+encodeURIComponent(n),true);
  if(!s.ok){toast(s.error||'Erreur');return;}
  render(s);toast('Pack « '+n+' » installé');
}
async function toggleFile(n){
  const s=await api('/api/mod?name='+encodeURIComponent(n)+'&action=toggle',true);
  if(!s.ok){toast(s.error||'Erreur');return;}
  render(s);toast('Fichier mis à jour');
}
async function deleteFile(n){
  if(!confirm('Supprimer '+n+' ?'))return;
  const s=await api('/api/mod?name='+encodeURIComponent(n)+'&action=delete',true);
  if(!s.ok){toast(s.error||'Erreur');return;}
  render(s);toast('Supprimé');
}
$('#play').onclick=async()=>{
  toast('Lancement demandé…');
  const s=await api('/api/launch',true);
  if(s.ok)toast('Le PC lance Minecraft');else toast(s.error||'Erreur');
};
api('/api/state').then(render).catch(()=>{ $('#host').textContent='PC injoignable — vérifie le Wi-Fi et le PIN'; });
setInterval(()=>{ if(document.hidden)return; api('/api/state').then(render).catch(()=>{}); },10000);
</script></body></html>"""


def resource(name):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


def find_java(base=None):
    """Cherche javaw.exe / java.exe dans le dossier runtime téléchargé par le launcher."""
    best = None
    for folder, _, files in os.walk(os.path.join(base or ROOT, "runtime")):
        for n in ("javaw.exe", "java.exe", "java"):
            if n in files and os.path.basename(folder) == "bin":
                p = os.path.join(folder, n)
                if n == "javaw.exe":
                    return p
                best = best or p
    return best


def load_cfg():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_cfg(cfg):
    os.makedirs(ROOT, exist_ok=True)
    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False)


def get_client_id(cfg=None):
    """Cherche le client ID Azure : config.json, variable d'env, client_id.txt, puis la constante.
    Ainsi on peut changer d'ID sans recompiler le .exe."""
    cfg = load_cfg() if cfg is None else cfg
    here = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
    candidates = [
        cfg.get("client_id"),
        os.environ.get("VORTEX_CLIENT_ID"),
    ]
    for path in (os.path.join(ROOT, "client_id.txt"), os.path.join(here, "client_id.txt")):
        try:
            with open(path, encoding="utf-8") as f:
                candidates.append(f.readline().strip())
        except OSError:
            pass
    candidates.append(CLIENT_ID)
    for cid in candidates:
        if cid and not str(cid).strip().startswith("VOTRE"):
            return str(cid).strip()
    return ""


# ---------- petit serveur local qui récupère le code OAuth ----------
LOGIN_PAGE = """<!doctype html><html lang="fr"><meta charset="utf-8">
<title>Vortex</title><body style="background:#0B0F1E;color:#E2E8F0;font-family:Segoe UI,sans-serif;
display:flex;height:100vh;align-items:center;justify-content:center;margin:0;text-align:center">
<div><h1 style="color:#3B82F6;margin:0">VORTEX <span style="color:#EF4444">2.0</span></h1>
<p>Connexion Microsoft réussie.</p><p style="color:#94A3B8">Tu peux fermer cet onglet et retourner sur le launcher.</p></div>
</body></html>""".encode("utf-8")


class LoginServer(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True
    address_family = socket.AF_INET6

    def server_bind(self):
        # écoute en IPv6 + IPv4 (localhost peut pointer sur ::1 ou 127.0.0.1)
        try:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except OSError:
            pass
        socketserver.TCPServer.server_bind(self)


class LoginHandler(socketserver.StreamRequestHandler):
    def handle(self):
        try:
            line = self.rfile.readline(65536).decode("latin-1")
            parts = line.split()
            query = urllib.parse.urlparse(parts[1] if len(parts) > 1 else "/").query
            params = urllib.parse.parse_qs(query)
            if "code" in params and not self.server.code:
                self.server.code = params["code"][0]
                self.server.state = (params.get("state") or [None])[0]
            elif "error" in params and not self.server.error:
                self.server.error = (params.get("error_description") or params["error"])[0]
            self.wfile.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                             b"Connection: close\r\nContent-Length: "
                             + str(len(LOGIN_PAGE)).encode() + b"\r\n\r\n" + LOGIN_PAGE)
        finally:
            self.server.done.set()


def start_login_server():
    """Écoute http://localhost (port 80). Renvoie None si le port est occupé."""
    for family, host in ((socket.AF_INET6, "::"), (socket.AF_INET, "127.0.0.1")):
        cls = type("Srv", (LoginServer,), {"address_family": family})
        try:
            srv = cls((host, 80), LoginHandler)
        except OSError:
            continue
        srv.code = srv.state = srv.error = None
        srv.done = threading.Event()
        threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.2}, daemon=True).start()
        return srv
    return None


# ---------- intégration au launcher Minecraft officiel ----------
def find_fabric_version(mc_dir, mc_version):
    """Renvoie l'id de la version Fabric installée pour cette version de Minecraft."""
    versions = os.path.join(mc_dir, "versions")
    found = []
    try:
        for name in os.listdir(versions):
            if name.startswith("fabric-loader-") and name.endswith("-" + mc_version):
                if os.path.isfile(os.path.join(versions, name, name + ".json")):
                    found.append((os.path.getmtime(os.path.join(versions, name)), name))
    except OSError:
        pass
    return max(found)[1] if found else None


def ensure_official_profile(mc_dir, version_id, game_dir):
    """Ajoute/actualise le profil « Vortex Client 2.0 » dans launcher_profiles.json."""
    path = os.path.join(mc_dir, "launcher_profiles.json")
    data = {}
    if os.path.isfile(path):
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f) or {}
        except Exception:
            data = {}
    if not isinstance(data.get("profiles"), dict):
        data["profiles"] = {}
    now = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())
    profile = data["profiles"].get(PROFILE_KEY) or {}
    profile.update({
        "name": "Vortex Client 2.0",
        "type": "custom",
        "icon": "Grass",
        "lastVersionId": version_id,
        "gameDir": game_dir,
        "created": profile.get("created") or now,
        "lastUsed": now,
    })
    data["profiles"][PROFILE_KEY] = profile
    data.setdefault("settings", {})
    data.setdefault("version", 3)
    os.makedirs(mc_dir, exist_ok=True)
    tmp = path + ".vortex.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def open_official_launcher():
    """Démarre le launcher Minecraft officiel (installé ou version Microsoft Store)."""
    for exe in (
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     "Minecraft Launcher", "MinecraftLauncher.exe"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"),
                     "Minecraft Launcher", "MinecraftLauncher.exe"),
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     "Minecraft", "MinecraftLauncher.exe"),
    ):
        if os.path.isfile(exe):
            os.startfile(exe)
            return True
    # launcher installé via le Microsoft Store (AppID : Microsoft.4297127D64EC6_8wekyb3d8bbwe!Minecraft)
    subprocess.Popen(["explorer.exe", "shell:AppsFolder\\Microsoft.4297127D64EC6_8wekyb3d8bbwe!Minecraft"])
    return True


class RemoteHandler(BaseHTTPRequestHandler):
    """Petite API HTTP pour la page mobile / l'APK (Wi-Fi local uniquement)."""
    app = None

    def log_message(self, *args):
        pass

    def _send(self, code, body, ctype="application/json"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(data)
        except OSError:
            pass

    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")

    def _route(self, method):
        u = urllib.parse.urlparse(self.path)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        app = RemoteHandler.app
        if app is None:
            self._send(503, '{"ok":false,"error":"serveur arreté"}')
            return
        if u.path in ("/", "/index.html"):
            self._send(200, MOBILE_HTML, "text/html")
            return
        if q.get("pin") != app.remote_pin:
            self._send(403, '{"ok":false,"error":"code PIN invalide"}')
            return
        try:
            if u.path == "/api/state":
                self._send(200, json.dumps(app.remote_state()))
            elif method == "POST" and u.path == "/api/module":
                app.remote_module(q.get("name", ""), q.get("on") == "1")
                self._send(200, json.dumps(app.remote_state()))
            elif method == "POST" and u.path == "/api/launch":
                app.remote_launch()
                self._send(200, json.dumps({"ok": True}))
            elif method == "POST" and u.path == "/api/pack":
                app.remote_install_pack(q.get("name", ""))
                self._send(200, json.dumps(app.remote_state()))
            elif method == "POST" and u.path == "/api/mod":
                app.remote_mod(q.get("name", ""), q.get("action", ""))
                self._send(200, json.dumps(app.remote_state()))
            else:
                self._send(404, '{"ok":false,"error":"route inconnue"}')
        except Exception as e:                      # jamais de crash du serveur
            self._send(500, json.dumps({"ok": False, "error": str(e)}))


def local_ips():
    """Adresses IPv4 du PC sur le réseau local (pour l'URL affichée)."""
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127."):
                ips.add(ip)
    except OSError:
        pass
    return sorted(ips)


class App(ctk.CTk):
    # ---------------------------------------------------------------- fenêtre
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title("Vortex Client 2.0")
        try:
            self.iconbitmap(resource("logo.ico"))
        except Exception:
            pass
        self.geometry("1020x660")
        self.minsize(900, 600)
        self.configure(fg_color=BG)
        self.cfg = load_cfg()
        for k, v in (("theme", "Rouge"), ("menu_key", "RSHIFT"), ("menu_size", 1.0),
                     ("sound", True), ("hide_on_screenshot", False), ("modules", [])):
            self.cfg.setdefault(k, v)
        if self.cfg["theme"] not in THEMES:
            self.cfg["theme"] = "Rouge"
        self.accent, self.accent_hover = THEMES[self.cfg["theme"]]
        self.cfg["accent"] = self.accent
        self.modules_enabled = set(self.cfg.get("modules") or [])
        self.module_vars = {}
        self.remote_pin = str(self.cfg.get("remote_pin") or random.randint(1000, 9999))
        self.cfg["remote_pin"] = self.remote_pin
        self.remote_srv = None
        self.remote_error = ""
        self.maxv = 1
        self._themed = []
        self.nav = {}
        self.pages = {}
        self.current_page = "jouer"

        self._build_shell()
        self._build_pages()
        self.mode.set("Direct (hors-ligne)" if self.cfg.get("mode") == "direct" else "Launcher officiel")
        self.mode.configure(command=self.on_mode_change)
        self.refresh_account()
        self.on_mode_change(self.mode.get())
        self.on_ram(self.ram.get())
        self._recolor()
        self._show_page("jouer")
        self.after(150, lambda: self._show_page(self.current_page))
        self._dark_titlebar()
        if self.cfg.get("remote_on", True):
            self.after(500, self.start_remote)

    def destroy(self):
        self.stop_remote(silent=True)
        super().destroy()

    def _dark_titlebar(self):
        """Barre de titre sombre (Windows 10/11)."""
        if os.name != "nt":
            return
        try:
            import ctypes
            self.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            on = ctypes.c_int(1)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(on), ctypes.sizeof(on))
            color = ctypes.c_int(0x000C0808)   # COLORREF 0x00BBGGRR (fond #08080C)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(color), ctypes.sizeof(color))
        except Exception:
            pass

    # ---------------------------------------------------------------- coquille
    def _build_shell(self):
        self.sidebar = ctk.CTkFrame(self, width=76, corner_radius=0, fg_color=SIDEBAR)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        logo = ctk.CTkLabel(self.sidebar, text="V", font=(FONT, 26, "bold"), text_color=self.accent)
        logo.pack(pady=(18, 14))
        self._style(logo, "accent_text")

        nav = [
            ("jouer", "▶", "Jouer"),
            ("modules", "▦", "Modules"),
            ("packs", "▩", "Packs"),
            ("phone", "☎", "Téléphone"),
            ("compte", "◉", "Compte"),
            ("dossier", "▤", "Dossier"),
            ("reglages", "⚙", "Réglages"),
            ("apropos", "?", "À propos"),
        ]
        for key, glyph, _ in nav:
            b = ctk.CTkButton(self.sidebar, text=glyph, width=52, height=46, corner_radius=12,
                              fg_color="transparent", hover_color=CARD_2, text_color=MUTED,
                              font=("Segoe UI Symbol", 19), command=lambda k=key: self._show_page(k))
            b.pack(pady=3)
            self.nav[key] = b
        self.indicator = ctk.CTkFrame(self.sidebar, width=3, height=20, corner_radius=2, fg_color=self.accent)
        self._style(self.indicator, "accent_bg")

        ctk.CTkLabel(self.sidebar, text="2.0", font=(FONT, 10, "bold"), text_color=MUTED).pack(side="bottom", pady=12)

        self.main = ctk.CTkFrame(self, corner_radius=0, fg_color=BG)
        self.main.pack(side="left", fill="both", expand=True)

        header = ctk.CTkFrame(self.main, height=58, corner_radius=0, fg_color="transparent")
        header.pack(fill="x", padx=20, pady=(18, 4))
        self.page_title = ctk.CTkLabel(header, text="JOUER", font=(FONT, 13, "bold"),
                                       text_color=self.accent, fg_color=CARD, corner_radius=12,
                                       border_width=1, border_color=self.accent, padx=16, height=30)
        self.page_title.pack(side="left")
        self._style(self.page_title, "pill")

        chip = ctk.CTkFrame(header, fg_color=CARD, corner_radius=16, border_width=1, border_color=BORDER)
        chip.pack(side="right")
        avatar = ctk.CTkLabel(chip, text="V", width=26, height=26, corner_radius=13,
                              fg_color=self.accent, text_color="#FFFFFF", font=(FONT, 12, "bold"))
        avatar.pack(side="left", padx=(6, 7), pady=5)
        self._style(avatar, "accent_bg")
        self.acc_label = ctk.CTkLabel(chip, text="Non connecté", font=(FONT, 11), text_color=MUTED)
        self.acc_label.pack(side="left", padx=(0, 14))

        self.body_area = ctk.CTkFrame(self.main, corner_radius=0, fg_color="transparent")
        self.body_area.pack(fill="both", expand=True, padx=8)
        self.body_area.grid_rowconfigure(0, weight=1)
        self.body_area.grid_columnconfigure(0, weight=1)

        foot = ctk.CTkFrame(self.main, height=32, corner_radius=10, fg_color=PANEL,
                            border_width=1, border_color=BORDER)
        foot.pack(fill="x", padx=20, pady=(4, 14))
        foot.pack_propagate(False)
        self.footer_cfg = ctk.CTkLabel(foot, text="Config : vortex", font=(FONT, 10), text_color=MUTED)
        self.footer_cfg.pack(side="left", padx=14)
        self.footer_build = ctk.CTkLabel(foot, text=f"Build 2.0 · {MC_VERSION}", font=(FONT, 10), text_color=MUTED)
        self.footer_build.pack(side="right", padx=14)
        self.footer_bind = ctk.CTkLabel(foot, text="Bind menu : RSHIFT", font=(FONT, 10), text_color=MUTED)
        self.footer_bind.pack(side="right", padx=14)
        ctk.CTkLabel(foot, text="•", font=(FONT, 10), text_color=self.accent).pack(side="right")
        self._refresh_footer()

    # ---------------------------------------------------------------- helpers
    def _style(self, widget, kind):
        self._themed.append((widget, kind))
        return widget

    def _recolor(self):
        for w, kind in self._themed:
            try:
                if kind == "accent_bg":
                    w.configure(fg_color=self.accent)
                elif kind == "accent_text":
                    w.configure(text_color=self.accent)
                elif kind == "accent_btn":
                    w.configure(fg_color=self.accent, hover_color=self.accent_hover)
                elif kind == "slider":
                    w.configure(progress_color=self.accent, button_color=self.accent,
                                button_hover_color=self.accent_hover)
                elif kind == "switch":
                    w.configure(progress_color=self.accent)
                elif kind == "seg":
                    w.configure(selected_color=self.accent, selected_hover_color=self.accent_hover)
                elif kind == "bar":
                    w.configure(progress_color=self.accent)
                elif kind == "pill":
                    w.configure(border_color=self.accent, text_color=self.accent)
            except Exception:
                pass
        self._show_page(self.current_page)

    def _card(self, parent, title, sub=None):
        card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=14, border_width=1, border_color=BORDER)
        card.pack(fill="x", padx=2, pady=(0, 14))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=18, pady=14)
        ctk.CTkLabel(inner, text=title, font=(FONT, 15, "bold"), text_color=TEXT, anchor="w").pack(fill="x")
        if sub:
            ctk.CTkLabel(inner, text=sub, font=(FONT, 11), text_color=MUTED, anchor="w",
                         justify="left", wraplength=760).pack(fill="x", pady=(2, 8))
        return inner

    def _row(self, parent, text, factory, hint=None):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=5)
        left = ctk.CTkFrame(row, fg_color="transparent")
        left.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(left, text=text, font=(FONT, 12), text_color=TEXT, anchor="w").pack(fill="x")
        if hint:
            ctk.CTkLabel(left, text=hint, font=(FONT, 10), text_color=MUTED, anchor="w",
                         justify="left", wraplength=420).pack(fill="x")
        w = factory(row)
        w.pack(side="right", padx=(12, 0))
        return w

    def _beep(self):
        if not self.cfg.get("sound", True):
            return
        try:
            import winsound
            winsound.Beep(1050, 25)
        except Exception:
            pass

    def _refresh_footer(self):
        self.footer_bind.configure(text="Bind menu : " + str(self.cfg.get("menu_key", "RSHIFT")))
        self.footer_cfg.configure(text="Config : vortex")

    # ---------------------------------------------------------------- pages
    def _build_pages(self):
        builders = {
            "jouer": self._page_jouer,
            "modules": self._page_modules,
            "packs": self._page_packs,
            "phone": self._page_phone,
            "compte": self._page_compte,
            "dossier": self._page_dossier,
            "reglages": self._page_reglages,
            "apropos": self._page_apropos,
        }
        titles = {"jouer": "JOUER", "modules": "MODULES", "packs": "PACKS", "phone": "TÉLÉPHONE",
                  "compte": "COMPTE", "dossier": "DOSSIER", "reglages": "RÉGLAGES", "apropos": "À PROPOS"}
        for key, build in builders.items():
            page = ctk.CTkScrollableFrame(self.body_area, fg_color="transparent", corner_radius=0,
                                          scrollbar_fg_color="transparent",
                                          scrollbar_button_color=CARD_2, scrollbar_button_hover_color=BORDER)
            page.grid(row=0, column=0, sticky="nsew")
            page.grid_remove()
            build(page)
            self.pages[key] = page
        self.titles = titles

    def _show_page(self, key):
        if key not in self.pages:
            key = "jouer"
        self.current_page = key
        for k, page in self.pages.items():
            if k == key:
                page.grid()
            else:
                page.grid_remove()
        for k, btn in self.nav.items():
            active = (k == key)
            btn.configure(fg_color=CARD_2 if active else "transparent",
                          text_color=self.accent if active else MUTED)
        self.page_title.configure(text=self.titles.get(key, "JOUER"))
        self.update_idletasks()
        btn = self.nav.get(key)
        if btn is not None:
            try:
                self.indicator.place(x=0, y=btn.winfo_y() + max(0, (btn.winfo_height() - 20) // 2))
            except Exception:
                pass

    # ---- page JOUER
    def _page_jouer(self, page):
        hero = ctk.CTkFrame(page, fg_color="transparent")
        hero.pack(fill="x", padx=20, pady=(4, 12))
        left = ctk.CTkFrame(hero, fg_color="transparent")
        left.pack(side="left")
        line = ctk.CTkFrame(left, fg_color="transparent")
        line.pack(anchor="w")
        ctk.CTkLabel(line, text="VORTEX", font=(FONT, 30, "bold"), text_color=TEXT).pack(side="left")
        tag = ctk.CTkLabel(line, text=" 2.0", font=(FONT, 30, "bold"), text_color=self.accent)
        tag.pack(side="left")
        self._style(tag, "accent_text")
        ctk.CTkLabel(left, text=f"Minecraft {MC_VERSION}  ·  Fabric  ·  cheat intégré",
                     font=(FONT, 11), text_color=MUTED).pack(anchor="w")

        card = self._card(page, "Lancement", "Choisis le mode, la mémoire allouée et le serveur à rejoindre.")

        holder = {}
        def seg_factory(parent):
            self.mode = ctk.CTkSegmentedButton(parent, values=["Launcher officiel", "Direct (hors-ligne)"],
                                               width=330, height=30, corner_radius=8,
                                               fg_color=CARD_2, unselected_color=CARD_2,
                                               unselected_hover_color=BORDER, text_color=TEXT)
            self._style(self.mode, "seg")
            return self.mode
        self._row(card, "Mode de lancement", seg_factory,
                  "Officiel : installe le profil et passe par le launcher Minecraft. Direct : serveurs hors-ligne.")

        def server_factory(parent):
            self.server = ctk.CTkEntry(parent, width=330, height=30, corner_radius=8,
                                       fg_color=CARD_2, border_color=BORDER, placeholder_text="ex. play.monserveur.fr")
            return self.server
        self._row(card, "Serveur à rejoindre", server_factory, "Utilisé par le mode Direct (connexion automatique).")
        if self.cfg.get("server"):
            self.server.insert(0, self.cfg["server"])

        def ram_factory(parent):
            box = ctk.CTkFrame(parent, fg_color="transparent")
            self.ram_label = ctk.CTkLabel(box, text="", font=(FONT, 11), text_color=MUTED, width=64)
            self.ram_label.pack(side="right")
            self.ram = ctk.CTkSlider(box, from_=2, to=16, number_of_steps=14, width=240, height=16,
                                     fg_color=CARD_2, progress_color=self.accent,
                                     button_color=self.accent, button_hover_color=self.accent_hover,
                                     command=self.on_ram)
            self.ram.set(float(self.cfg.get("ram", 4)))
            self.ram.pack(side="left")
            self._style(self.ram, "slider")
            return box
        self._row(card, "Mémoire allouée", ram_factory, "2 Go suffisent pour jouer, 6–8 Go pour les mods lourds.")

        self.play = ctk.CTkButton(card, text="▶   JOUER", height=50, corner_radius=12,
                                  font=(FONT, 17, "bold"), text_color="#FFFFFF", command=self.start)
        self.play.pack(fill="x", pady=(14, 8))
        self._style(self.play, "accent_btn")

        self.bar = ctk.CTkProgressBar(card, height=6, corner_radius=3, fg_color=CARD_2)
        self.bar.set(0)
        self.bar.pack(fill="x")
        self._style(self.bar, "bar")
        self.status = ctk.CTkLabel(card, text="Prêt.", font=(FONT, 11), text_color=MUTED)
        self.status.pack(anchor="w", pady=(6, 0))

    # ---- page MODULES
    def _page_modules(self, page):
        card = self._card(page, "Modules",
                          "Cochés ici, ils sont activés automatiquement au démarrage du jeu. "
                          "Tu peux aussi les activer en jeu avec le menu (Shift droit par défaut).")
        grid = ctk.CTkFrame(card, fg_color="transparent")
        grid.pack(fill="x", pady=(6, 0))
        for col in range(3):
            grid.grid_columnconfigure(col, weight=1)
        for i, (name, desc) in enumerate(MODULES):
            cell = ctk.CTkFrame(grid, fg_color=CARD_2, corner_radius=10)
            cell.grid(row=i // 3, column=i % 3, sticky="ew", padx=4, pady=4)
            txt = ctk.CTkFrame(cell, fg_color="transparent")
            txt.pack(side="left", fill="x", expand=True, padx=(10, 4), pady=8)
            ctk.CTkLabel(txt, text=name, font=(FONT, 12, "bold"), text_color=TEXT, anchor="w").pack(fill="x")
            ctk.CTkLabel(txt, text=desc, font=(FONT, 9), text_color=MUTED, anchor="w",
                         justify="left", wraplength=175).pack(fill="x")
            var = tk.BooleanVar(value=name in self.modules_enabled)
            self.module_vars[name] = var
            sw = ctk.CTkSwitch(cell, text="", width=44, variable=var, onvalue=True, offvalue=False,
                               fg_color=BORDER, progress_color=self.accent,
                               command=lambda n=name, v=var: self.on_module(n, v))
            sw.pack(side="right", padx=(0, 6))
            self._style(sw, "switch")

    # ---- page PACKS
    def _page_packs(self, page):
        card = self._card(page, "Mes packs",
                          "Un pack = un dossier de mods (celui d'une instance CurseForge, Prism ou MultiMC). "
                          "Importe-le une fois, puis installe-le en un clic dans le client. "
                          f"Les packs sont rangés dans {PACKS_DIR}.")
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x")
        for text, cmd in (("Importer un pack (dossier)", self.import_pack),
                          ("Importer « pack pvp »", self.import_curseforge_pack),
                          ("Ouvrir le dossier des packs", lambda: self._open_path(PACKS_DIR)),
                          ("Rafraîchir", self._refresh_packs)):
            b = ctk.CTkButton(row, text=text, height=32, corner_radius=8, fg_color=CARD_2,
                              hover_color=BORDER, border_width=1, border_color=BORDER,
                              text_color=TEXT, font=(FONT, 11), command=cmd)
            b.pack(side="left", padx=(0, 8))
        self.packs_box = ctk.CTkFrame(card, fg_color="transparent")
        self.packs_box.pack(fill="x", pady=(10, 0))
        self.packs_status = ctk.CTkLabel(card, text="", font=(FONT, 10), text_color=MUTED, anchor="w")
        self.packs_status.pack(fill="x", pady=(8, 0))

        card2 = self._card(page, "Mods installés",
                           "Fabric charge tout ce qui est dans ce dossier au démarrage. "
                           "Désactiver renomme le fichier en .jar.disabled : il reste là mais n'est plus chargé.")
        row2 = ctk.CTkFrame(card2, fg_color="transparent")
        row2.pack(fill="x")
        for text, cmd in (("Ajouter des .jar", self.add_mods),
                          ("Importer un dossier de mods", self.import_mods_folder),
                          ("Ouvrir le dossier mods", lambda: self._open_path(MODS_DIR)),
                          ("Rafraîchir", self._refresh_mods)):
            b = ctk.CTkButton(row2, text=text, height=32, corner_radius=8, fg_color=CARD_2,
                              hover_color=BORDER, border_width=1, border_color=BORDER,
                              text_color=TEXT, font=(FONT, 11), command=cmd)
            b.pack(side="left", padx=(0, 8))
        self.mods_box = ctk.CTkScrollableFrame(card2, height=240, fg_color=CARD_2, corner_radius=10)
        self.mods_box.pack(fill="x", pady=(10, 0))
        self._refresh_packs()
        self._refresh_mods()

    # ---- page TÉLÉPHONE
    def _page_phone(self, page):
        card = self._card(page, "Télécommande téléphone",
                          "Le launcher ouvre une page web sur ton réseau Wi-Fi : modules, packs et lancement "
                          "depuis le téléphone. Installe l'APK, ou ouvre simplement l'adresse dans le navigateur.")
        self.remote_state_label = ctk.CTkLabel(card, text="", font=(FONT, 12, "bold"),
                                               text_color=MUTED, anchor="w")
        self.remote_state_label.pack(fill="x")
        self.remote_urls = ctk.CTkLabel(card, text="", font=("Consolas", 11), text_color=TEXT, anchor="w",
                                        justify="left", fg_color=CARD_2, corner_radius=8, padx=12, pady=10)
        self.remote_urls.pack(fill="x", pady=(8, 10))

        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x")
        self.remote_btn = ctk.CTkButton(row, text="Démarrer", width=120, height=32, corner_radius=8,
                                        text_color="#FFFFFF", font=(FONT, 11, "bold"),
                                        command=self.toggle_remote)
        self._style(self.remote_btn, "accent_btn")
        self.remote_btn.pack(side="left", padx=(0, 8))
        for text, cmd in (("Ouvrir dans le navigateur", self.open_remote_browser),
                          ("Copier l'adresse", self.copy_remote_url),
                          ("Nouveau code PIN", self.new_remote_pin)):
            ctk.CTkButton(row, text=text, height=32, corner_radius=8, fg_color=CARD_2,
                          hover_color=BORDER, border_width=1, border_color=BORDER,
                          text_color=TEXT, font=(FONT, 11), command=cmd).pack(side="left", padx=(0, 8))

        ctk.CTkLabel(card, text="Le téléphone doit être sur le même Wi-Fi. Au premier lancement, "
                                "Windows demande d'autoriser Python/le launcher sur le réseau : clique Autoriser.",
                     font=(FONT, 10), text_color=MUTED, anchor="w", justify="left",
                     wraplength=720).pack(fill="x", pady=(8, 0))

        card2 = self._card(page, "APK Android",
                           "L'APK est un écran de contrôle : Minecraft Java + Fabric ne peut pas tourner sur "
                           "Android. Installe l'APK, entre l'adresse affichée plus haut, et tu pilotes le PC.")
        apk = self._apk_path()
        ctk.CTkLabel(card2, text=apk if apk else
                     "APK introuvable : lance build_android.ps1 (dossier android) pour le générer.",
                     font=("Consolas", 11), text_color=TEXT, anchor="w", fg_color=CARD_2,
                     corner_radius=8, padx=12, pady=10).pack(fill="x", pady=(0, 10))
        row2 = ctk.CTkFrame(card2, fg_color="transparent")
        row2.pack(fill="x")
        ctk.CTkButton(row2, text="Copier l'APK sur le Bureau", height=32, corner_radius=8,
                      fg_color=CARD_2, hover_color=BORDER, border_width=1, border_color=BORDER,
                      text_color=TEXT, font=(FONT, 11), command=self.copy_apk_desktop).pack(side="left", padx=(0, 8))
        ctk.CTkButton(row2, text="Ouvrir le dossier", height=32, corner_radius=8,
                      fg_color=CARD_2, hover_color=BORDER, border_width=1, border_color=BORDER,
                      text_color=TEXT, font=(FONT, 11),
                      command=lambda: self._open_path(os.path.dirname(self._apk_path() or ROOT))).pack(side="left")
        self._remote_status()

    # ---- page COMPTE
    def _page_compte(self, page):
        card = self._card(page, "Compte Microsoft",
                          "Nécessaire pour le mode Direct en ligne. Le mode Launcher officiel utilise "
                          "directement le compte connecté dans le launcher Minecraft.")
        self.home_account = ctk.CTkLabel(card, text="", font=(FONT, 12), text_color=TEXT, anchor="w")
        self.home_account.pack(fill="x", pady=(0, 8))
        self.ms_btn = ctk.CTkButton(card, text="Se connecter avec Microsoft", height=38, corner_radius=10,
                                    font=(FONT, 12, "bold"), text_color="#FFFFFF", command=self.login_ms)
        self.ms_btn.pack(anchor="w")
        self._style(self.ms_btn, "accent_btn")

        card2 = self._card(page, "Pseudo hors-ligne",
                           "Utilisé uniquement en mode Direct quand aucun compte Microsoft n'est connecté.")

        def name_factory(parent):
            self.name = ctk.CTkEntry(parent, width=330, height=30, corner_radius=8,
                                     fg_color=CARD_2, border_color=BORDER, placeholder_text="VortexUser")
            return self.name
        self._row(card2, "Pseudo", name_factory)
        if self.cfg.get("offline_name"):
            self.name.insert(0, self.cfg["offline_name"])

    # ---- page DOSSIER
    def _page_dossier(self, page):
        card = self._card(page, "Dossier de jeu",
                          "C'est ici que le launcher installe Minecraft, Java, Fabric et le mod quand "
                          "tu utilises le mode Direct. Le profil du launcher officiel pointe aussi sur ce dossier.")
        ctk.CTkLabel(card, text=ROOT, font=("Consolas", 11), text_color=TEXT, anchor="w",
                     fg_color=CARD_2, corner_radius=8, padx=12, pady=10).pack(fill="x", pady=(0, 10))
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x")
        for text, path in (("Ouvrir le dossier", ROOT),
                           ("Ouvrir les mods", os.path.join(ROOT, "mods")),
                           ("Ouvrir les logs", os.path.join(ROOT, "logs"))):
            b = ctk.CTkButton(row, text=text, height=32, corner_radius=8, fg_color=CARD_2,
                              hover_color=BORDER, border_width=1, border_color=BORDER,
                              text_color=TEXT, font=(FONT, 11),
                              command=lambda p=path: self._open_path(p))
            b.pack(side="left", padx=(0, 8))

        card2 = self._card(page, "Fichier de configuration",
                           "Le launcher et le mod partagent ce fichier : thème, touche du menu, taille, "
                           "modules activés au démarrage.")
        ctk.CTkLabel(card2, text=CONFIG, font=("Consolas", 11), text_color=TEXT, anchor="w",
                     fg_color=CARD_2, corner_radius=8, padx=12, pady=10).pack(fill="x")

    def _open_path(self, path):
        try:
            os.makedirs(path, exist_ok=True)
            os.startfile(path)
        except Exception as e:
            messagebox.showerror("Vortex Client", f"Impossible d'ouvrir :\n{path}\n\n{e}")

    # ---------------------------------------------------------------- packs & mods
    def _status_packs(self, text):
        if hasattr(self, "packs_status"):
            self.packs_status.configure(text=text)

    def _refresh_packs(self):
        if not hasattr(self, "packs_box"):
            return
        for w in self.packs_box.winfo_children():
            w.destroy()
        try:
            names = sorted(d for d in os.listdir(PACKS_DIR)
                           if os.path.isdir(os.path.join(PACKS_DIR, d)))
        except OSError:
            names = []
        if not names:
            ctk.CTkLabel(self.packs_box,
                         text="Aucun pack pour l'instant. Clique sur « Importer un pack (dossier) » "
                              "et choisis le dossier « mods » d'une instance, ou sur « Importer « pack pvp » ».",
                         font=(FONT, 11), text_color=MUTED, anchor="w", justify="left",
                         wraplength=720).pack(fill="x", pady=6)
            return
        for name in names:
            path = os.path.join(PACKS_DIR, name)
            try:
                jars = [f for f in os.listdir(path) if f.lower().endswith(".jar")]
            except OSError:
                jars = []
            line = ctk.CTkFrame(self.packs_box, fg_color=CARD_2, corner_radius=10)
            line.pack(fill="x", pady=3)
            ctk.CTkLabel(line, text=name, font=(FONT, 12, "bold"), text_color=TEXT,
                         anchor="w").pack(side="left", padx=(12, 8), pady=8)
            ctk.CTkLabel(line, text=f"{len(jars)} mods", font=(FONT, 10),
                         text_color=MUTED).pack(side="left")
            b = ctk.CTkButton(line, text="Installer", width=92, height=26, corner_radius=8,
                              text_color="#FFFFFF", font=(FONT, 11, "bold"),
                              command=lambda p=path: self.install_pack(p))
            self._style(b, "accent_btn")
            b.pack(side="right", padx=(6, 10), pady=6)
            ctk.CTkButton(line, text="Supprimer", width=92, height=26, corner_radius=8,
                          fg_color="transparent", hover_color=BORDER, border_width=1,
                          border_color=BORDER, text_color=MUTED, font=(FONT, 11),
                          command=lambda p=path: self.delete_pack(p)).pack(side="right", pady=6)
            ctk.CTkButton(line, text="Ouvrir", width=70, height=26, corner_radius=8,
                          fg_color="transparent", hover_color=BORDER, border_width=1,
                          border_color=BORDER, text_color=TEXT, font=(FONT, 11),
                          command=lambda p=path: self._open_path(p)).pack(side="right", padx=6, pady=6)

    def install_pack(self, path):
        """Copie les .jar d'un pack dans le dossier mods du client."""
        try:
            copied, skipped = self._copy_pack(path)
        except OSError as e:
            messagebox.showerror("Vortex Client", f"Dossier illisible :\n{e}")
            return
        if copied == 0 and skipped == 0:
            messagebox.showwarning("Vortex Client", "Ce pack ne contient aucun .jar.")
            return
        self._refresh_mods()
        self._beep()
        text = f"{copied} mods installés depuis « {os.path.basename(path)} »"
        if skipped:
            text += f" · {skipped} ignoré(s) : le client Vortex est déjà installé"
        self._status_packs(text)

    def _copy_pack(self, path):
        """Copie les .jar d'un pack vers MODS_DIR. Renvoie (copiés, ignorés)."""
        jars = [f for f in os.listdir(path) if f.lower().endswith(".jar")]
        os.makedirs(MODS_DIR, exist_ok=True)
        copied = skipped = 0
        for f in jars:
            if f.lower().startswith(("vortx-", "vortex-client")):
                skipped += 1          # le client Vortex est déjà fourni par le launcher
                continue
            shutil.copy2(os.path.join(path, f), os.path.join(MODS_DIR, f))
            copied += 1
        return copied, skipped

    def import_pack(self):
        src = filedialog.askdirectory(title="Choisis le dossier « mods » du pack")
        if src:
            self._import_pack_from(src)

    def import_curseforge_pack(self):
        base = os.path.join(os.environ.get("USERPROFILE") or "", "curseforge", "minecraft", "Instances")
        found = []
        if os.path.isdir(base):
            for d in sorted(os.listdir(base)):
                m = os.path.join(base, d, "mods")
                if os.path.isdir(m) and any(f.lower().endswith(".jar") for f in os.listdir(m)):
                    found.append(m)
        if not found:
            messagebox.showinfo("Vortex Client",
                                "Aucune instance CurseForge trouvée dans\n" + base +
                                "\n\nUtilise « Importer un pack (dossier) » et choisis le dossier mods à la main.")
            return
        src = found[0]
        if len(found) > 1:
            names = ", ".join(os.path.basename(os.path.dirname(m)) for m in found)
            choice = ctk.CTkInputDialog(
                text=f"Instances trouvées : {names}\n\nTape le nom de l'instance à importer :",
                title="CurseForge").get_input()
            if not choice:
                return
            for m in found:
                if os.path.basename(os.path.dirname(m)).lower() == choice.strip().lower():
                    src = m
                    break
        self._import_pack_from(src)

    def _import_pack_from(self, src):
        src = os.path.normpath(src)
        try:
            files = [f for f in os.listdir(src) if f.lower().endswith((".jar", ".jar.disabled"))]
        except OSError as e:
            messagebox.showerror("Vortex Client", f"Dossier illisible :\n{e}")
            return
        if not files:
            messagebox.showwarning("Vortex Client", "Aucun mod (.jar) dans ce dossier.")
            return
        name = os.path.basename(src)
        if name.lower() in ("mods", ".minecraft"):
            name = os.path.basename(os.path.dirname(src)) or "pack"
        dst = os.path.join(PACKS_DIR, name)
        if os.path.isdir(dst) and not messagebox.askyesno(
                "Vortex Client", f"Le pack « {name} » existe déjà. Le remplacer ?"):
            return
        os.makedirs(dst, exist_ok=True)
        for f in files:
            try:
                shutil.copy2(os.path.join(src, f), os.path.join(dst, f))
            except OSError as e:
                messagebox.showerror("Vortex Client", f"Impossible de copier {f} :\n{e}")
                return
        self._refresh_packs()
        self._beep()
        self._status_packs(f"Pack « {name} » importé ({len(files)} fichiers).")
        if messagebox.askyesno("Vortex Client",
                               f"Pack « {name} » importé.\nL'installer tout de suite dans le client ?"):
            self.install_pack(dst)

    def delete_pack(self, path):
        name = os.path.basename(path)
        if not messagebox.askyesno("Vortex Client", f"Supprimer le pack « {name} » ?"):
            return
        try:
            shutil.rmtree(path)
        except OSError as e:
            messagebox.showerror("Vortex Client", f"Impossible de supprimer :\n{e}")
            return
        self._refresh_packs()
        self._beep()
        self._status_packs(f"Pack « {name} » supprimé.")

    def add_mods(self):
        files = filedialog.askopenfilenames(title="Choisis des mods (.jar)",
                                            filetypes=[("Mods Fabric", "*.jar")])
        if not files:
            return
        os.makedirs(MODS_DIR, exist_ok=True)
        for f in files:
            try:
                shutil.copy2(f, MODS_DIR)
            except OSError as e:
                messagebox.showerror("Vortex Client", f"Impossible de copier {f} :\n{e}")
                return
        self._refresh_mods()
        self._beep()

    def import_mods_folder(self):
        src = filedialog.askdirectory(title="Choisis un dossier de mods")
        if not src:
            return
        try:
            files = [f for f in os.listdir(src) if f.lower().endswith((".jar", ".jar.disabled"))]
        except OSError as e:
            messagebox.showerror("Vortex Client", f"Dossier illisible :\n{e}")
            return
        os.makedirs(MODS_DIR, exist_ok=True)
        for f in files:
            try:
                shutil.copy2(os.path.join(src, f), os.path.join(MODS_DIR, f))
            except OSError as e:
                messagebox.showerror("Vortex Client", f"Impossible de copier {f} :\n{e}")
                return
        self._refresh_mods()
        self._beep()

    def toggle_mod(self, name):
        src = os.path.join(MODS_DIR, name)
        dst = src[:-9] if name.lower().endswith(".disabled") else src + ".disabled"
        try:
            os.replace(src, dst)
        except OSError as e:
            messagebox.showerror("Vortex Client", f"Impossible de renommer :\n{e}")
            return
        self._refresh_mods()
        self._beep()

    def delete_mod(self, name):
        if not messagebox.askyesno("Vortex Client", f"Supprimer « {name} » du dossier mods ?"):
            return
        try:
            os.remove(os.path.join(MODS_DIR, name))
        except OSError as e:
            messagebox.showerror("Vortex Client", f"Impossible de supprimer :\n{e}")
            return
        self._refresh_mods()
        self._beep()

    def _refresh_mods(self):
        if not hasattr(self, "mods_box"):
            return
        for w in self.mods_box.winfo_children():
            w.destroy()
        try:
            files = [f for f in os.listdir(MODS_DIR) if f.lower().endswith((".jar", ".jar.disabled"))]
        except OSError:
            files = []
        files.sort(key=lambda f: (f.lower().endswith(".disabled"), f.lower()))
        if not files:
            ctk.CTkLabel(self.mods_box, text="Aucun mod installé. Ajoute des .jar ou installe un pack.",
                         font=(FONT, 11), text_color=MUTED).pack(pady=16)
            return
        for f in files:
            p = os.path.join(MODS_DIR, f)
            disabled = f.lower().endswith(".disabled")
            try:
                size = os.path.getsize(p) / (1024 * 1024)
            except OSError:
                size = 0
            row = ctk.CTkFrame(self.mods_box, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=3)
            ctk.CTkLabel(row, text=f[:-9] if disabled else f, font=(FONT, 11),
                         text_color=MUTED if disabled else TEXT, anchor="w").pack(side="left")
            ctk.CTkLabel(row, text=f"{size:.1f} Mo", font=(FONT, 9),
                         text_color=MUTED).pack(side="left", padx=8)
            if disabled:
                ctk.CTkLabel(row, text="désactivé", font=(FONT, 9),
                             text_color="#F59E0B").pack(side="left")
            ctk.CTkButton(row, text="Suppr.", width=64, height=24, corner_radius=7,
                          fg_color="transparent", hover_color=BORDER, border_width=1,
                          border_color=BORDER, text_color=MUTED, font=(FONT, 10),
                          command=lambda n=f: self.delete_mod(n)).pack(side="right", padx=(6, 0))
            ctk.CTkButton(row, text="Activer" if disabled else "Désactiver", width=86, height=24,
                          corner_radius=7, fg_color=CARD, hover_color=BORDER, border_width=1,
                          border_color=BORDER, text_color=TEXT, font=(FONT, 10),
                          command=lambda n=f: self.toggle_mod(n)).pack(side="right")

    # ---------------------------------------------------------------- télécommande (APK / navigateur)
    def _apk_path(self):
        here = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
        for p in (resource(APK_NAME), os.path.join(here, APK_NAME)):
            if os.path.isfile(p):
                return p
        return ""

    def start_remote(self):
        if self.remote_srv is not None:
            return
        try:
            srv = ThreadingHTTPServer(("0.0.0.0", REMOTE_PORT), RemoteHandler)
        except OSError as e:
            self.remote_error = ("port 8765 déjà utilisé" if getattr(e, "errno", 0) in (98, 10048, 10013)
                                 else str(e))
            self._remote_status()
            return
        self.remote_error = ""
        RemoteHandler.app = self
        self.remote_srv = srv
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.cfg["remote_on"] = True
        save_cfg(self.cfg)
        self._remote_status()

    def stop_remote(self, silent=False):
        srv, self.remote_srv = self.remote_srv, None
        RemoteHandler.app = None
        if srv is not None:
            try:
                srv.shutdown()
                srv.server_close()
            except Exception:
                pass
        if not silent:
            self.cfg["remote_on"] = False
            save_cfg(self.cfg)
            self._remote_status()

    def toggle_remote(self):
        if self.remote_srv:
            self.stop_remote()
        else:
            self.start_remote()
        self._beep()

    def _remote_urls(self):
        return [f"http://{ip}:{REMOTE_PORT}/?pin={self.remote_pin}" for ip in local_ips()]

    def _remote_status(self):
        if not hasattr(self, "remote_state_label"):
            return
        if self.remote_srv:
            self.remote_state_label.configure(text=f"Serveur actif  ·  code PIN {self.remote_pin}",
                                              text_color="#22C55E")
            self.remote_btn.configure(text="Arrêter")
            urls = self._remote_urls()
            self.remote_urls.configure(text="\n".join(urls) or
                                       "Aucune adresse réseau : connecte le PC au Wi-Fi / à la box.")
        else:
            msg = "Serveur arrêté"
            if self.remote_error:
                msg += f"  ·  {self.remote_error}"
            self.remote_state_label.configure(text=msg,
                                              text_color="#F59E0B" if self.remote_error else MUTED)
            self.remote_btn.configure(text="Démarrer")
            self.remote_urls.configure(text=f"http://<IP-du-PC>:{REMOTE_PORT}/?pin={self.remote_pin}")

    def open_remote_browser(self):
        if not self.remote_srv:
            self.start_remote()
        urls = self._remote_urls()
        if urls:
            webbrowser.open(urls[0])
        else:
            messagebox.showinfo("Vortex Client", "Aucune adresse réseau détectée.")

    def copy_remote_url(self):
        urls = self._remote_urls() if self.remote_srv else []
        self.clipboard_clear()
        self.clipboard_append(urls[0] if urls else f"http://<IP-du-PC>:{REMOTE_PORT}/?pin={self.remote_pin}")
        self._beep()

    def new_remote_pin(self):
        self.remote_pin = str(random.randint(1000, 9999))
        self.cfg["remote_pin"] = self.remote_pin
        save_cfg(self.cfg)
        self._remote_status()
        self._beep()

    def copy_apk_desktop(self):
        apk = self._apk_path()
        if not apk:
            messagebox.showwarning("Vortex Client",
                                   "APK introuvable.\nLance android\\build_android.ps1 pour le générer.")
            return
        try:
            desktop = os.path.join(os.environ.get("USERPROFILE") or "", "Desktop")
            dst = os.path.join(desktop, APK_NAME)
            shutil.copy2(apk, dst)
            messagebox.showinfo("Vortex Client",
                                "APK copié sur le Bureau :\n" + dst +
                                "\n\nTransfère-le sur le téléphone (câble, Drive…) puis installe-le.")
        except OSError as e:
            messagebox.showerror("Vortex Client", f"Copie impossible :\n{e}")

    # ---- API utilisée par la page mobile et l'APK
    def remote_state(self):
        mods, packs = [], []
        try:
            for f in sorted(os.listdir(MODS_DIR)):
                if f.lower().endswith((".jar", ".jar.disabled")):
                    try:
                        size = os.path.getsize(os.path.join(MODS_DIR, f)) / 1048576
                    except OSError:
                        size = 0
                    mods.append({"name": f, "disabled": f.lower().endswith(".disabled"),
                                 "size": round(size, 1)})
        except OSError:
            pass
        try:
            for d in sorted(os.listdir(PACKS_DIR)):
                p = os.path.join(PACKS_DIR, d)
                if os.path.isdir(p):
                    try:
                        n = sum(1 for f in os.listdir(p) if f.lower().endswith(".jar"))
                    except OSError:
                        n = 0
                    packs.append({"name": d, "count": n})
        except OSError:
            pass
        host = f"{socket.gethostname()} · PIN {self.remote_pin}"
        return {"ok": True, "host": host,
                "modules": [{"name": n, "desc": d, "on": n in self.modules_enabled} for n, d in MODULES],
                "mods": mods, "packs": packs}

    def remote_module(self, name, on):
        if name not in dict(MODULES):
            raise ValueError("module inconnu")
        if on:
            self.modules_enabled.add(name)
        else:
            self.modules_enabled.discard(name)
        self.cfg["modules"] = sorted(self.modules_enabled)
        save_cfg(self.cfg)
        var = self.module_vars.get(name)
        if var is not None:
            self.after(0, lambda v=var, o=on: v.set(o))

    def remote_launch(self):
        self.after(0, self.start)

    def remote_install_pack(self, name):
        path = os.path.join(PACKS_DIR, os.path.basename(name or ""))
        if not os.path.isdir(path):
            raise ValueError("pack inconnu")
        copied, skipped = self._copy_pack(path)
        if copied == 0 and skipped == 0:
            raise ValueError("pack vide")

    def remote_mod(self, name, action):
        name = os.path.basename(name or "")
        path = os.path.join(MODS_DIR, name)
        if not name or not os.path.isfile(path):
            raise ValueError("fichier inconnu")
        if action == "toggle":
            dst = path[:-9] if name.lower().endswith(".disabled") else path + ".disabled"
            os.replace(path, dst)
        elif action == "delete":
            os.remove(path)
        else:
            raise ValueError("action inconnue")

    # ---- page RÉGLAGES
    def _page_reglages(self, page):
        card = self._card(page, "Interface", "Ces réglages sont enregistrés et appliqués aussi au menu en jeu.")

        def theme_factory(parent):
            self.theme_menu = ctk.CTkSegmentedButton(parent, values=list(THEMES.keys()), width=330,
                                                     height=30, corner_radius=8, fg_color=CARD_2,
                                                     unselected_color=CARD_2, unselected_hover_color=BORDER,
                                                     text_color=TEXT, command=self.set_theme)
            self.theme_menu.set(self.cfg["theme"])
            self._style(self.theme_menu, "seg")
            return self.theme_menu
        self._row(card, "Couleur d'accent", theme_factory)

        def sound_factory(parent):
            var = tk.BooleanVar(value=bool(self.cfg.get("sound", True)))
            sw = ctk.CTkSwitch(parent, text="", width=44, variable=var, onvalue=True, offvalue=False,
                               fg_color=BORDER, progress_color=self.accent,
                               command=lambda: self.set_option("sound", var.get()))
            self._style(sw, "switch")
            return sw
        self._row(card, "Sons du launcher", sound_factory, "Petit bip lors des actions.")

        def hide_factory(parent):
            var = tk.BooleanVar(value=bool(self.cfg.get("hide_on_screenshot", False)))
            sw = ctk.CTkSwitch(parent, text="", width=44, variable=var, onvalue=True, offvalue=False,
                               fg_color=BORDER, progress_color=self.accent,
                               command=lambda: self.set_option("hide_on_screenshot", var.get()))
            self._style(sw, "switch")
            return sw
        self._row(card, "Masquer le HUD en capture", hide_factory,
                  "Le HUD disparaît pendant que tu maintiens F2 (capture d'écran).")

        card2 = self._card(page, "Touches et menu", "Identiques à ceux utilisés en jeu par le mod.")

        def bind_factory(parent):
            self.bind_menu = ctk.CTkOptionMenu(parent, values=BINDS, width=180, height=30, corner_radius=8,
                                               fg_color=CARD_2, button_color=CARD_2,
                                               button_hover_color=BORDER, text_color=TEXT,
                                               dropdown_fg_color=CARD, dropdown_hover_color=CARD_2,
                                               dropdown_text_color=TEXT, command=self.set_bind)
            self.bind_menu.set(self.cfg.get("menu_key", "RSHIFT"))
            return self.bind_menu
        self._row(card2, "Ouvrir le menu", bind_factory)

        def size_factory(parent):
            box = ctk.CTkFrame(parent, fg_color="transparent")
            self.size_label = ctk.CTkLabel(box, text="", width=58, font=(FONT, 11), text_color=MUTED)
            self.size_label.pack(side="right")
            self.size_slider = ctk.CTkSlider(box, from_=0.7, to=1.6, number_of_steps=18, width=240,
                                             height=16, fg_color=CARD_2, progress_color=self.accent,
                                             button_color=self.accent, button_hover_color=self.accent_hover,
                                             command=self.set_menu_size)
            self.size_slider.set(float(self.cfg.get("menu_size", 1.0)))
            self.size_slider.pack(side="left")
            self._style(self.size_slider, "slider")
            self.size_label.configure(text=f"× {self.size_slider.get():.2f}")
            return box
        self._row(card2, "Taille du menu", size_factory, "Agrandit ou réduit le menu en jeu.")

    # ---- page À PROPOS
    def _page_apropos(self, page):
        card = self._card(page, "Vortex Client 2.0",
                          f"Launcher + mod Fabric pour Minecraft {MC_VERSION}. "
                          "Le mod est injecté automatiquement dans le dossier de jeu.")
        for k, v in (("Version", "2.0"), ("Minecraft", MC_VERSION), ("Loader", "Fabric"),
                     ("Modules", str(len(MODULES))), ("Build", time.strftime("%d/%m/%Y"))):
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", pady=3)
            ctk.CTkLabel(row, text=k, font=(FONT, 11), text_color=MUTED).pack(side="left")
            ctk.CTkLabel(row, text=v, font=(FONT, 11, "bold"), text_color=TEXT).pack(side="right")

        card2 = self._card(page, "Limites côté client",
                           "Les dégâts, la portée et les mouvements sont validés par le serveur. "
                           "Aucun client ne peut rendre invincible : NoFall et Velocity limitent "
                           "seulement les dégâts de chute et le recul.")
        ctk.CTkLabel(card2, text="Serveur d'un ami : pas de server.properties à modifier, "
                                "l'anti-kick du Fly est donc géré côté client.",
                     font=(FONT, 11), text_color=MUTED, anchor="w", justify="left",
                     wraplength=760).pack(fill="x")

    # ---------------------------------------------------------------- réglages
    def on_module(self, name, var):
        if var.get():
            self.modules_enabled.add(name)
        else:
            self.modules_enabled.discard(name)
        self.cfg["modules"] = sorted(self.modules_enabled)
        save_cfg(self.cfg)
        self._beep()

    def set_theme(self, name):
        if name not in THEMES:
            return
        self.accent, self.accent_hover = THEMES[name]
        self.cfg["theme"] = name
        self.cfg["accent"] = self.accent
        save_cfg(self.cfg)
        self._recolor()
        self._beep()

    def set_option(self, key, value):
        self.cfg[key] = value
        save_cfg(self.cfg)
        self._beep()

    def set_bind(self, value):
        self.cfg["menu_key"] = value
        save_cfg(self.cfg)
        self._refresh_footer()
        self._beep()

    def set_menu_size(self, v):
        self.cfg["menu_size"] = round(float(v), 2)
        self.size_label.configure(text=f"× {self.cfg['menu_size']:.2f}")
        save_cfg(self.cfg)

    # ---------------------------------------------------------------- UI helpers (thread-safe)
    def on_ram(self, v):
        self.ram_label.configure(text=f"{int(float(v))} Go")

    def on_mode_change(self, value):
        official = value.startswith("Launcher")
        state = "disabled" if official else "normal"
        self.ms_btn.configure(state=state)
        self.name.configure(state=state)
        if official:
            self.acc_label.configure(text="Compte : launcher officiel")
            if hasattr(self, "home_account"):
                self.home_account.configure(text="Compte : celui du launcher Minecraft officiel")
        else:
            self.refresh_account()

    def set_status(self, t):
        self.after(0, lambda: self.status.configure(text=t))

    def set_max(self, m):
        self.maxv = max(int(m), 1)

    def set_progress(self, v):
        self.after(0, lambda: self.bar.set(min(max(v / self.maxv, 0), 1)))

    def refresh_account(self):
        acc = self.cfg.get("account")
        text = f"Connecté : {acc['name']}" if acc else "Non connecté à Microsoft"
        self.acc_label.configure(text=text)
        if hasattr(self, "home_account"):
            self.home_account.configure(text=text)

    # ---------- Connexion Microsoft ---------
    def login_ms(self):
        cid = get_client_id(self.cfg)
        if not cid:
            self.ask_client_id()
            return
        self.ms_btn.configure(state="disabled")
        self.set_status("Connexion Microsoft : en attente du navigateur…")
        threading.Thread(target=self._ms_login, args=(cid,), daemon=True).start()

    def ask_client_id(self):
        self.ms_btn.configure(state="normal")
        msg = ("Aucun client ID Azure n'est configuré, donc la connexion Microsoft "
               "officielle n'est pas possible pour l'instant.\n\n"
               "À faire une seule fois (gratuit, ~5 min) :\n"
               "1. portal.azure.com → App registrations → New registration\n"
               "2. Supported account types : « Personal Microsoft accounts »\n"
               "3. Redirect URI : type « Public client/native » puis  http://localhost\n"
               "4. Register, puis copie l'« Application (client) ID » et colle-le "
               "dans la fenêtre suivante.\n\n"
               "Ouvrir le portail Azure maintenant ?")
        if messagebox.askyesno("Connexion Microsoft", msg):
            webbrowser.open("https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade")
        cid = ctk.CTkInputDialog(text="Colle ici l'Application (client) ID :",
                                 title="Client ID Azure").get_input()
        if not cid or not cid.strip():
            self.set_status("Prêt.")
            return
        cid = cid.strip().strip('"').strip("'")
        if len(cid) < 8:
            messagebox.showerror("Client ID Azure", "Cet ID ne ressemble pas à un client ID Azure.")
            return
        self.cfg["client_id"] = cid
        save_cfg(self.cfg)
        self.set_status("Client ID enregistré. Connexion…")
        self.login_ms()

    def _ms_login(self, cid):
        """Tourne dans un thread : ouvre le navigateur et attend le retour sur localhost."""
        try:
            url, state, verifier = mll.microsoft_account.get_secure_login_data(cid, REDIRECT_URL)
        except Exception as e:
            self.after(0, lambda e=e: self._login_failed(cid, e))
            return

        srv = start_login_server()
        webbrowser.open(url)
        if srv is None:
            # port 80 occupé : on laisse l'utilisateur coller l'URL finale
            self.after(0, lambda: self._login_paste(cid, state, verifier))
            return

        got = srv.done.wait(LOGIN_TIMEOUT)
        srv.shutdown()
        srv.server_close()
        code, err, got_state = srv.code, srv.error, srv.state
        if not got or (not code and not err):
            self.set_status("Connexion Microsoft : délai dépassé, réessaie.")
            self.after(0, lambda: self.ms_btn.configure(state="normal"))
            return
        if err:
            self.after(0, lambda err=err: self._login_failed(cid, RuntimeError(err)))
            return
        if state and got_state and got_state != state:
            self.after(0, lambda: self._login_failed(cid, RuntimeError("Réponse invalide (state différent).")))
            return
        self._finish_login(cid, code, verifier)

    def _login_paste(self, cid, state, verifier):
        res = ctk.CTkInputDialog(
            text="Le navigateur n'a pas pu renvoyer la réponse automatiquement.\n"
                 "Colle ici l'URL complète de la page finale (http://localhost/?code=...) :",
            title="Microsoft").get_input()
        if not res:
            self.set_status("Connexion annulée.")
            self.ms_btn.configure(state="normal")
            return
        try:
            code = mll.microsoft_account.parse_auth_code_url(res.strip(), state)
        except Exception as e:
            self._login_failed(cid, e)
            return
        threading.Thread(target=self._finish_login, args=(cid, code, verifier), daemon=True).start()

    def _finish_login(self, cid, code, verifier):
        try:
            data = mll.microsoft_account.complete_login(cid, None, REDIRECT_URL, code, verifier)
            self.cfg["account"] = {k: data.get(k, "") for k in ("name", "id", "access_token", "refresh_token")}
            self.cfg["client_id"] = cid
            save_cfg(self.cfg)
            name = data.get("name") or "compte Microsoft"
            self.set_status(f"Connecté : {name}")
            self.after(0, self.refresh_account)
        except Exception as e:
            self.after(0, lambda e=e: self._login_failed(cid, e))
        finally:
            self.after(0, lambda: self.ms_btn.configure(state="normal"))

    def _login_failed(self, cid, e):
        self.ms_btn.configure(state="normal")
        self.set_status("Prêt.")
        messagebox.showerror("Microsoft", f"Connexion échouée :\n{e}")

    def get_session(self):
        acc = self.cfg.get("account")
        if acc:
            cid = get_client_id(self.cfg)
            if not cid:
                raise RuntimeError("Client ID Azure manquant : reconnecte-toi via le bouton Microsoft.")
            try:
                data = mll.microsoft_account.complete_refresh(cid, None, REDIRECT_URL, acc["refresh_token"])
                self.cfg["account"] = {k: data[k] for k in ("name", "id", "access_token", "refresh_token")}
                save_cfg(self.cfg)
                a = self.cfg["account"]
                return a["name"], a["id"], a["access_token"]
            except Exception:
                raise RuntimeError("Session Microsoft expirée : reconnecte-toi.")
        name = self.name.get().strip() or "VortexUser"
        return name, str(uuid.uuid3(uuid.NAMESPACE_OID, "OfflinePlayer:" + name)), "0"

    # ---------- Lancement ----------
    def start(self):
        self.cfg["offline_name"] = self.name.get().strip()
        self.cfg["server"] = self.server.get().strip()
        self.cfg["ram"] = int(self.ram.get())
        self.cfg["mode"] = "official" if self.mode.get().startswith("Launcher") else "direct"
        save_cfg(self.cfg)
        self._beep()
        self.play.configure(state="disabled")
        target = self.run_official if self.cfg["mode"] == "official" else self.run_direct
        threading.Thread(target=target, daemon=True).start()

    def ensure_mods(self, mods_dir):
        os.makedirs(mods_dir, exist_ok=True)
        if not any(f.startswith("fabric-api") for f in os.listdir(mods_dir)):
            self.set_status("Téléchargement de Fabric API…")
            q = urllib.parse.urlencode({"game_versions": json.dumps([MC_VERSION]), "loaders": json.dumps(["fabric"])})
            req = urllib.request.Request(f"https://api.modrinth.com/v2/project/fabric-api/version?{q}",
                                         headers={"User-Agent": "VortexClient/2.0"})
            f = json.load(urllib.request.urlopen(req))[0]["files"][0]
            urllib.request.urlretrieve(f["url"], os.path.join(mods_dir, f["filename"]))
        shutil.copy(resource("vortex-client.jar"), os.path.join(mods_dir, "vortex-client.jar"))

    def install_java(self, directory):
        """Installe le Java de Mojang dans <directory>/runtime et renvoie le chemin de java.exe."""
        info = mll.runtime.get_version_runtime_information(MC_VERSION, directory)
        if not info:
            raise RuntimeError("Impossible de trouver la version de Java requise.")
        mll.runtime.install_jvm_runtime(info["name"], directory, callback={
            "setStatus": self.set_status, "setProgress": self.set_progress, "setMax": self.set_max})
        java = find_java(directory)
        if not java:
            raise RuntimeError("Java introuvable dans " + os.path.join(directory, "runtime")
                               + "\nSupprime ce dossier runtime et relance JOUER.")
        # l'installateur de Fabric appelle "java" : on le met dans le PATH pour ce programme
        os.environ["PATH"] = os.path.dirname(java) + os.pathsep + os.environ.get("PATH", "")
        return java

    # --- Mode 1 : tout est préparé puis ouvert dans le launcher Minecraft officiel ---
    def run_official(self):
        try:
            cb = {"setStatus": self.set_status, "setProgress": self.set_progress, "setMax": self.set_max}
            os.makedirs(MC_DIR, exist_ok=True)
            self.set_status("Installation de Minecraft dans le launcher officiel…")
            mll.install.install_minecraft_version(MC_VERSION, MC_DIR, callback=cb)

            java = find_java(MC_DIR) or self.install_java(MC_DIR)
            vid = find_fabric_version(MC_DIR, MC_VERSION)
            if not vid:
                self.set_status("Installation de Fabric…")
                mll.fabric.install_fabric(MC_VERSION, MC_DIR, callback=cb, java=java)
                vid = find_fabric_version(MC_DIR, MC_VERSION)
            if not vid:
                vid = f"fabric-loader-{mll.fabric.get_latest_loader_version()}-{MC_VERSION}"

            self.set_status("Installation du mod Vortex…")
            self.ensure_mods(os.path.join(GAME_DIR, "mods"))
            ensure_official_profile(MC_DIR, vid, GAME_DIR)

            self.set_status("Ouverture du launcher Minecraft officiel…")
            open_official_launcher()
            self.set_status("Launcher officiel ouvert : profil « Vortex Client 2.0 » → JOUER.")
        except Exception as e:
            self._fatal(e)
        finally:
            self.after(0, lambda: self.play.configure(state="normal"))

    # --- Mode 2 : lancement direct, sans le launcher officiel (serveurs cracked) ---
    def run_direct(self):
        try:
            os.makedirs(ROOT, exist_ok=True)
            cb = {"setStatus": self.set_status, "setProgress": self.set_progress, "setMax": self.set_max}
            self.set_status("Installation de Minecraft…")
            mll.install.install_minecraft_version(MC_VERSION, ROOT, callback=cb)
            self.set_status("Installation de Java (automatique)…")
            java = self.install_java(ROOT)
            self.set_status("Installation de Fabric…")
            mll.fabric.install_fabric(MC_VERSION, ROOT, callback=cb, java=java)
            vid = f"fabric-loader-{mll.fabric.get_latest_loader_version()}-{MC_VERSION}"
            self.ensure_mods(os.path.join(ROOT, "mods"))
            name, uid, token = self.get_session()
            ram = int(self.cfg["ram"])
            options = {"username": name, "uuid": uid, "token": token, "executablePath": java,
                       "jvmArguments": [f"-Xmx{ram}G", f"-Xms{min(2, ram)}G"]}
            if self.cfg.get("server"):
                options["quickPlayMultiplayer"] = self.cfg["server"]
            cmd = mll.command.get_minecraft_command(vid, ROOT, options)
            self.set_status("Lancement de Minecraft…")
            flags = 0x08000000 if os.name == "nt" else 0   # CREATE_NO_WINDOW
            log = open(os.path.join(ROOT, "game.log"), "w", encoding="utf-8", errors="replace")
            log.write("Commande : " + " ".join(str(c) for c in cmd[:3]) + " ...\n")
            log.flush()
            subprocess.Popen(cmd, cwd=ROOT, creationflags=flags, stdout=log, stderr=subprocess.STDOUT)
            self.set_status("Minecraft démarre. Menu Vortex : " + str(self.cfg.get("menu_key", "RSHIFT")))
        except Exception as e:
            self._fatal(e)
        finally:
            self.after(0, lambda: self.play.configure(state="normal"))

    def _fatal(self, e):
        import traceback
        try:
            with open(os.path.join(ROOT, "erreur.log"), "w", encoding="utf-8") as f:
                f.write(traceback.format_exc())
        except Exception:
            pass
        self.set_status("Erreur.")
        self.after(0, lambda: messagebox.showerror("Vortex Client", str(e)))


if __name__ == "__main__":
    App().mainloop()
