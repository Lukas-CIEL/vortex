package fr.vortex.modules;
import fr.vortex.Hack;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
/**
 * ChestStealer : vide le coffre ouvert. Utilise uniquement des transferts vanilla
 * (maj + clic = QUICK_MOVE), donc aucun paquet impossible : indétectable par un anticheat.
 * Un délai évite de vider 27 stacks dans le même tick (ce qui, lui, se verrait).
 */
public class ChestStealer extends Hack {
    public static int DELAY = 2;   // ticks entre deux transferts

    private int timer;

    public ChestStealer() { super("ChestStealer"); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || !(mc.currentScreen instanceof HandledScreen<?> screen)) { timer = 0; return; }
        var handler = screen.getScreenHandler();
        if (handler instanceof PlayerScreenHandler) return;   // pas notre propre inventaire
        if (timer-- > 0) return;
        timer = Math.max(1, DELAY);
        for (var slot : handler.slots) {
            if (!slot.hasStack() || slot.inventory == p.getInventory()) continue;
            if (!slot.canTakeItems(p)) continue;
            mc.interactionManager.clickSlot(handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, p);
            return;
        }
    }
}
