package fr.vortex;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * ESP : cadres 2D projetés à l'écran, visibles à travers les murs.
 * Aucun accès au moteur de rendu : uniquement du HUD, donc 100 % client.
 */
public class Esp {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    /** Rectangle écran {x1, y1, x2, y2} du cube, ou null si derrière / hors champ. */
    public static int[] rect(Box b, float td) {
        var p = mc.player;
        if (p == null) return null;
        Vec3d lp = p.getLerpedPos(td);
        Vec3d cam = lp.add(0, p.getEyeY() - p.getY(), 0);
        double yaw = Math.toRadians(p.getYaw(td)), pit = Math.toRadians(p.getPitch(td));
        Vec3d f = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit));
        Vec3d r = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d u = r.crossProduct(f);
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double scale = (h / 2.0) / Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            Vec3d v = new Vec3d((i & 1) == 0 ? b.minX : b.maxX,
                                (i & 2) == 0 ? b.minY : b.maxY,
                                (i & 4) == 0 ? b.minZ : b.maxZ).subtract(cam);
            double z = v.dotProduct(f);
            if (z < 0.1) return null;
            double sx = w / 2.0 + v.dotProduct(r) / z * scale;
            double sy = h / 2.0 - v.dotProduct(u) / z * scale;
            minX = Math.min(minX, sx); maxX = Math.max(maxX, sx);
            minY = Math.min(minY, sy); maxY = Math.max(maxY, sy);
        }
        if (maxX < 0 || minX > w || maxY < 0 || minY > h) return null;
        return new int[]{(int) minX, (int) minY, (int) maxX, (int) maxY};
    }

    /** Cadre complet avec un contour sombre pour rester lisible. */
    public static int[] box(DrawContext c, Box b, float td, int argb) {
        int[] r = rect(b, td);
        if (r == null) return null;
        int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];
        c.fill(x1 - 1, y1 - 1, x2 + 1, y1, 0x70000000);
        c.fill(x1 - 1, y2, x2 + 1, y2 + 1, 0x70000000);
        c.fill(x1 - 1, y1, x1, y2, 0x70000000);
        c.fill(x2, y1, x2 + 1, y2, 0x70000000);
        c.fill(x1, y1, x2, y1 + 1, argb);
        c.fill(x1, y2 - 1, x2, y2, argb);
        c.fill(x1, y1, x1 + 1, y2, argb);
        c.fill(x2 - 1, y1, x2, y2, argb);
        return r;
    }

    /** Coins façon client (brackets), plus discret qu'un cadre complet. */
    public static int[] corners(DrawContext c, Box b, float td, int argb) {
        int[] r = rect(b, td);
        if (r == null) return null;
        int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];
        int w = Math.max(1, x2 - x1), h = Math.max(1, y2 - y1);
        int lx = Math.max(4, Math.min(12, w / 3));
        int ly = Math.max(4, Math.min(12, h / 3));
        int sh = 0x70000000;
        // ombre (1 px autour)
        cornerShadow(c, x1 - 1, y1 - 1, x2 + 1, y2 + 1, lx + 1, ly + 1, sh);
        cornerShadow(c, x1, y1, x2, y2, lx, ly, argb);
        return r;
    }

    private static void cornerShadow(DrawContext c, int x1, int y1, int x2, int y2,
                                     int lx, int ly, int color) {
        // horizontal, 2 px d'épaisseur
        c.fill(x1, y1, x1 + lx, y1 + 2, color);
        c.fill(x2 - lx, y1, x2, y1 + 2, color);
        c.fill(x1, y2 - 2, x1 + lx, y2, color);
        c.fill(x2 - lx, y2 - 2, x2, y2, color);
        // vertical, 2 px d'épaisseur
        c.fill(x1, y1, x1 + 2, y1 + ly, color);
        c.fill(x2 - 2, y1, x2, y1 + ly, color);
        c.fill(x1, y2 - ly, x1 + 2, y2, color);
        c.fill(x2 - 2, y2 - ly, x2, y2, color);
    }

    /** Texte avec un fond sombre translucide (nom, PV, distance). */
    public static void label(DrawContext c, String text, int x, int y, int color) {
        var tr = mc.textRenderer;
        int w = tr.getWidth(text);
        c.fill(x - 2, y - 1, x + w + 2, y + 9, 0x78000000);
        c.drawText(tr, text, x, y, color, false);
    }

    /**
     * Cadre de conteneur : liseré coloré, contour sombre et léger remplissage.
     * Si le bloc est trop proche (un coin passe derrière la caméra), on bascule
     * sur un carré centré sur le bloc : le coffre ne disparaît plus de l'écran.
     */
    public static int[] container(DrawContext c, Box b, float td, int argb) {
        int[] r = rect(b, td);
        if (r == null) return billboard(c, b, td, argb);
        int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];
        c.fill(x1, y1, x2, y2, (argb & 0x00FFFFFF) | 0x28000000);
        // contour sombre
        c.fill(x1 - 1, y1 - 1, x2 + 1, y1, 0x90000000);
        c.fill(x1 - 1, y2, x2 + 1, y2 + 1, 0x90000000);
        c.fill(x1 - 1, y1, x1, y2, 0x90000000);
        c.fill(x2, y1, x2 + 1, y2, 0x90000000);
        // liseré coloré (2 px)
        c.fill(x1, y1, x2, y1 + 2, argb);
        c.fill(x1, y2 - 2, x2, y2, argb);
        c.fill(x1, y1, x1 + 2, y2, argb);
        c.fill(x2 - 2, y1, x2, y2, argb);
        return r;
    }

    /** Carré à l'écran centré sur le bloc (repli quand la boîte 3D sort du champ proche). */
    private static int[] billboard(DrawContext c, Box b, float td, int argb) {
        var p = mc.player;
        if (p == null) return null;
        Vec3d cam = p.getLerpedPos(td).add(0, p.getEyeY() - p.getY(), 0);
        double yaw = Math.toRadians(p.getYaw(td)), pit = Math.toRadians(p.getPitch(td));
        Vec3d f = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit));
        Vec3d r = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d u = r.crossProduct(f);
        Vec3d v = b.getCenter().subtract(cam);
        double z = v.dotProduct(f);
        if (z < 0.1) return null;
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double scale = (h / 2.0) / Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double half = Math.max(0.5, Math.max(b.maxX - b.minX,
                            Math.max(b.maxY - b.minY, b.maxZ - b.minZ)) / 2.0);
        int hs = (int) Math.max(4, Math.min(80, half * scale / Math.max(0.35, z)));
        int cx = (int) (w / 2.0 + v.dotProduct(r) / z * scale);
        int cy = (int) (h / 2.0 - v.dotProduct(u) / z * scale);
        int x1 = cx - hs, y1 = cy - hs, x2 = cx + hs, y2 = cy + hs;
        if (x2 < 0 || x1 > w || y2 < 0 || y1 > h) return null;
        c.fill(x1, y1, x2, y2, (argb & 0x00FFFFFF) | 0x28000000);
        c.fill(x1, y1, x2, y1 + 2, argb);
        c.fill(x1, y2 - 2, x2, y2, argb);
        c.fill(x1, y1, x1 + 2, y2, argb);
        c.fill(x2 - 2, y1, x2, y2, argb);
        return new int[]{x1, y1, x2, y2};
    }

    /** Projette un point du monde à l'écran. Renvoie {x, y} ou null si derrière la caméra. */
    public static int[] project(Vec3d world, float td) {
        var p = mc.player;
        if (p == null) return null;
        Vec3d cam = p.getLerpedPos(td).add(0, p.getEyeY() - p.getY(), 0);
        double yaw = Math.toRadians(p.getYaw(td)), pit = Math.toRadians(p.getPitch(td));
        Vec3d f = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit));
        Vec3d r = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d u = r.crossProduct(f);
        Vec3d v = world.subtract(cam);
        double z = v.dotProduct(f);
        if (z < 0.1) return null;
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double scale = (h / 2.0) / Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        return new int[]{
            (int) (w / 2.0 + v.dotProduct(r) / z * scale),
            (int) (h / 2.0 - v.dotProduct(u) / z * scale)
        };
    }
}
