package fr.vortex;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
public abstract class Hack {
    public static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name;
    public boolean enabled;
    protected Hack(String name) { this.name = name; }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onHud(DrawContext ctx, float tickDelta) {}
}
