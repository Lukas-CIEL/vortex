package fr.vortex.modules;

import fr.vortex.Esp;
import fr.vortex.Hack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * ESP Enemy : cadre sur les mobs (monstres en orange, animaux en jaune).
 * Les joueurs sont gérés séparément par ESP Player.
 */
public class ESPEnemy extends Hack {
    public static int RANGE = 96;
    public static boolean SHOW_INFO = true;

    private static final int HOSTILE = 0xFFFF7043;
    private static final int PASSIVE = 0xFFFACC15;
    private static final int BAR_BG = 0x90000000;

    public ESPEnemy() { super("ESP Enemy"); }

    @Override public void onHud(DrawContext c, float td) {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        Box area = p.getBoundingBox().expand(RANGE);
        double max = (double) RANGE * RANGE;
        for (MobEntity e : mc.world.getEntitiesByClass(MobEntity.class, area, e -> e.isAlive())) {
            if (p.squaredDistanceTo(e) > max) continue;
            draw(c, e, td, p, e instanceof Monster ? HOSTILE : PASSIVE);
        }
    }

    private void draw(DrawContext c, LivingEntity e, float td, PlayerEntity viewer, int color) {
        Vec3d lp = e.getLerpedPos(td);
        Box b = e.getBoundingBox().offset(lp.x - e.getX(), lp.y - e.getY(), lp.z - e.getZ());
        int[] r = Esp.box(c, b, td, color);
        if (r == null) return;
        int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];
        int w = Math.max(1, x2 - x1);

        float ratio = e.getHealth() / Math.max(1f, e.getMaxHealth());
        ratio = Math.max(0f, Math.min(1f, ratio));
        c.fill(x1, y2 + 2, x2, y2 + 5, BAR_BG);
        c.fill(x1, y2 + 2, x1 + (int) (w * ratio), y2 + 5, color);

        if (!SHOW_INFO) return;
        int dist = (int) Math.sqrt(viewer.squaredDistanceTo(e));
        String text = e.getName().getString() + "  " + Math.round(e.getHealth()) + " HP  " + dist + "m";
        int tx = x1 + Math.max(0, (w - mc.textRenderer.getWidth(text)) / 2);
        Esp.label(c, text, tx, Math.max(0, y1 - 11), color);
    }
}
