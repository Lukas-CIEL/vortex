package fr.vortex.modules;

import fr.vortex.Esp;
import fr.vortex.Hack;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP conteneurs : coffres, barils, coffres de l'Ender et shulkers.
 *
 * On lit les block entities des chunks chargés (au lieu de balayer chaque bloc),
 * donc c'est quasi gratuit même à 128 blocs.
 *
 * Chaque type a sa couleur, les doubles coffres sont fusionnés en une seule
 * boîte, et un carré de secours s'affiche quand on est trop près pour projeter
 * la boîte 3D (sinon l'ESP disparaissait au contact).
 */
public class ESPChest extends Hack {
    public static int RANGE_XZ = 128;          // rayon horizontal, en blocs
    public static int RANGE_Y = 64;            // rayon vertical, en blocs
    public static int LABEL_FROM = 8;          // distance mini pour afficher le texte
    public static boolean LABELS = true;       // nom + distance
    public static boolean CORNERS = false;     // coins style client au lieu du cadre
    public static boolean SHULKERS_ONLY = false;

    private static final int REFRESH = 10;     // ticks entre deux scans (0,5 s)

    private static final int COL_CHEST = 0xFF4EA1FF;    // coffres : bleu
    private static final int COL_BARREL = 0xFFFFA23A;   // barils : orange
    private static final int COL_ENDER = 0xFFB45CFF;    // ender chest : violet
    private static final int COL_SHULKER = 0xFF22D3EE;  // shulkers : cyan

    private static final class Marker {
        final Box box;
        final Vec3d center;
        final int color;
        final String name;

        Marker(Box box, int color, String name) {
            this.box = box;
            this.center = box.getCenter();
            this.color = color;
            this.name = name;
        }
    }

    private final List<Marker> markers = new ArrayList<>();
    private int timer;

    public ESPChest() { super("ESP Chest"); }

    @Override public void onTick() {
        if (mc.world == null || mc.player == null || timer-- > 0) return;
        timer = REFRESH;
        List<Marker> tmp = new ArrayList<>();
        BlockPos center = mc.player.getBlockPos();
        int cx0 = (center.getX() - RANGE_XZ) >> 4, cx1 = (center.getX() + RANGE_XZ) >> 4;
        int cz0 = (center.getZ() - RANGE_XZ) >> 4, cz1 = (center.getZ() + RANGE_XZ) >> 4;
        for (int cx = cx0; cx <= cx1; cx++) {
            for (int cz = cz0; cz <= cz1; cz++) {
                WorldChunk chunk;
                try {
                    chunk = mc.world.getChunk(cx, cz);
                } catch (Exception e) {
                    continue;
                }
                if (chunk == null || chunk.getBlockEntities().isEmpty()) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    Marker m = identify(be, center);
                    if (m != null) tmp.add(m);
                }
            }
        }
        markers.clear();
        markers.addAll(tmp);
    }

    private Marker identify(BlockEntity be, BlockPos origin) {
        BlockPos p = be.getPos();
        if (Math.abs(p.getY() - origin.getY()) > RANGE_Y) return null;
        if (p.getSquaredDistance(origin) > (double) RANGE_XZ * RANGE_XZ + (double) RANGE_Y * RANGE_Y)
            return null;

        if (be instanceof ShulkerBoxBlockEntity)
            return new Marker(new Box(p), COL_SHULKER, "Shulker");
        if (SHULKERS_ONLY) return null;
        if (be instanceof BarrelBlockEntity)
            return new Marker(new Box(p), COL_BARREL, "Baril");
        if (be instanceof EnderChestBlockEntity)
            return new Marker(new Box(p), COL_ENDER, "Ender");
        if (!(be instanceof ChestBlockEntity)) return null;

        Box box = new Box(p);
        BlockState st = mc.world.getBlockState(p);
        if (st.getBlock() instanceof ChestBlock) {
            ChestType type = st.get(ChestBlock.CHEST_TYPE);
            if (type != ChestType.SINGLE) {
                Direction facing = st.get(ChestBlock.FACING);
                Direction side = type == ChestType.LEFT
                        ? facing.rotateYCounterclockwise()
                        : facing.rotateYClockwise();
                BlockPos other = p.offset(side);
                if (mc.world.getBlockEntity(other) instanceof ChestBlockEntity) {
                    // une seule moitié dessine la boîte fusionnée
                    if (type != ChestType.LEFT) return null;
                    box = box.union(new Box(other));
                }
            }
        }
        return new Marker(box, COL_CHEST, "Coffre");
    }

    @Override public void onHud(DrawContext c, float td) {
        var p = mc.player;
        if (p == null) return;
        Vec3d eye = p.getEyePos();
        for (Marker m : markers) {
            int[] r = CORNERS ? Esp.corners(c, m.box, td, m.color)
                              : Esp.container(c, m.box, td, m.color);
            if (r == null || !LABELS) continue;
            double dist = Math.sqrt(eye.squaredDistanceTo(m.center));
            if (dist < LABEL_FROM) continue;
            String txt = m.name + "  " + (int) dist + "m";
            int tx = r[0] + Math.max(0, (r[2] - r[0] - mc.textRenderer.getWidth(txt)) / 2);
            Esp.label(c, txt, tx, Math.max(0, r[1] - 11), m.color);
        }
    }
}
