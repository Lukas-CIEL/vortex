package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.util.math.Vec3d;

/**
 * AirJump : permet un saut supplémentaire en l'air (double saut).
 * POWER = impulsion verticale, COOLDOWN = ticks avant de pouvoir recommencer.
 */
public class AirJump extends Hack {
    public static double POWER = 0.42;
    public static int COOLDOWN = 6;

    private int cooldown;
    private boolean wasJump;

    public AirJump() { super("AirJump"); }

    @Override public void onEnable() { cooldown = 0; wasJump = false; }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (cooldown > 0) cooldown--;

        boolean jump = mc.options.jumpKey.isPressed();
        if (jump && !wasJump && cooldown == 0
                && !p.isOnGround() && !p.isTouchingWater() && !p.isInLava()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, POWER, v.z);
            p.setOnGround(false);
            cooldown = Math.max(1, COOLDOWN);
        }
        wasJump = jump;
    }
}
