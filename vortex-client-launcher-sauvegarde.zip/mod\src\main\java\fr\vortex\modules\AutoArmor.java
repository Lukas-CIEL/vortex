package fr.vortex.modules;
import fr.vortex.Hack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
/**
 * AutoArmor : enfile la meilleure pièce d'armure de la barre rapide,
 * et remplace l'armure portée si la pièce est meilleure.
 * Passe par un simple clic droit vanilla (le serveur ne voit qu'une action de joueur).
 */
public class AutoArmor extends Hack {
    public static int DELAY = 6;        // ticks entre deux tentatives
    public static boolean UPGRADE = true; // remplacer une pièce par une meilleure

    private int timer;

    public AutoArmor() { super("AutoArmor"); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null || mc.interactionManager == null) return;
        if (timer-- > 0) return;
        timer = Math.max(1, DELAY);
        var inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isEmpty()) continue;
            var eq = stack.get(DataComponentTypes.EQUIPPABLE);
            if (eq == null || !eq.slot().isArmorSlot() || !eq.equipOnInteract()) continue;
            EquipmentSlot slot = eq.slot();
            double mine = armorValue(stack, slot);
            if (mine <= 0) continue;
            ItemStack worn = p.getEquippedStack(slot);
            if (!worn.isEmpty()) {
                if (!UPGRADE || mine <= armorValue(worn, slot) + 0.01) continue;
            }
            inv.setSelectedSlot(i);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            return;
        }
    }

    private static double armorValue(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty()) return 0;
        var mods = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
        return mods == null ? 0 : mods.applyOperations(EntityAttributes.ARMOR, 0, slot);
    }
}
