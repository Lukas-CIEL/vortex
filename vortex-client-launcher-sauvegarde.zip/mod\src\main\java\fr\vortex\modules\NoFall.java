package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * NoFall : le serveur reçoit un paquet « je suis au sol » pendant la chute,
 * ce qui annule les dégâts de chute. Classique, mais peut être détecté par
 * un serveur qui vérifie la cohérence des positions.
 */
public class NoFall extends Hack {
    public static double MIN_FALL = 2.0;   // blocs de chute avant d'agir
    public static int INTERVAL = 8;        // ticks entre deux paquets

    private int timer;

    public NoFall() { super("NoFall"); }

    @Override public void onEnable() { timer = 0; }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.networkHandler == null) return;
        if (p.fallDistance > MIN_FALL && !p.isOnGround()) {
            if (timer-- <= 0) {
                p.networkHandler.sendPacket(
                    new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
                timer = Math.max(1, INTERVAL);
            }
            p.fallDistance = 0f;
        }
    }
}
