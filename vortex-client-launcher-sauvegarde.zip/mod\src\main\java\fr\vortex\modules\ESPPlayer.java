package fr.vortex.modules;

import fr.vortex.Esp;
import fr.vortex.Hack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * ESP Player : cadre sur les joueurs uniquement, avec nom, points de vie,
 * distance et barre de vie. Visibles à travers les murs (rendu HUD pur).
 */
public class ESPPlayer extends Hack {
    public static int RANGE = 128;          // distance max d'affichage
    public static boolean SHOW_INFO = true; // nom + PV + distance
    public static boolean SHOW_BAR = true;  // barre de vie sous le cadre
    public static boolean CORNERS = true;   // coins façon client (sinon cadre plein)

    private static final int COLOR = 0xFFEF4444;
    private static final int BAR_BG = 0x90000000;
    private static final int HP_GOOD = 0xFF22C55E;
    private static final int HP_MID = 0xFFF59E0B;
    private static final int HP_LOW = 0xFFEF4444;

    public ESPPlayer() { super("ESP Player"); }

    @Override public void onHud(DrawContext c, float td) {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        double max = (double) RANGE * RANGE;
        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator()) continue;
            if (p.squaredDistanceTo(e) > max) continue;
            draw(c, e, td, p);
        }
    }

    private void draw(DrawContext c, PlayerEntity e, float td, PlayerEntity viewer) {
        Vec3d lp = e.getLerpedPos(td);
        Box b = e.getBoundingBox().offset(lp.x - e.getX(), lp.y - e.getY(), lp.z - e.getZ());
        int[] r = CORNERS ? Esp.corners(c, b, td, COLOR) : Esp.box(c, b, td, COLOR);
        if (r == null) return;
        int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];
        int w = Math.max(1, x2 - x1);

        if (SHOW_BAR) {
            float ratio = e.getHealth() / Math.max(1f, e.getMaxHealth());
            ratio = Math.max(0f, Math.min(1f, ratio));
            int hp = ratio > 0.5f ? HP_GOOD : ratio > 0.25f ? HP_MID : HP_LOW;
            c.fill(x1, y2 + 2, x2, y2 + 5, BAR_BG);
            c.fill(x1, y2 + 2, x1 + (int) (w * ratio), y2 + 5, hp);
        }

        if (!SHOW_INFO) return;
        int dist = (int) Math.sqrt(viewer.squaredDistanceTo(e));
        String text = e.getName().getString() + "  " + Math.round(e.getHealth()) + " HP  " + dist + "m";
        int tx = x1 + Math.max(0, (w - mc.textRenderer.getWidth(text)) / 2);
        Esp.label(c, text, tx, Math.max(0, y1 - 11), COLOR);
    }
}
