package fr.vortex;
import fr.vortex.modules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import java.util.List;
public class VortexClient implements ClientModInitializer {
    public static final List<Hack> modules = List.of(
        new Fly(), new SpeedHack(), new Sprint(), new Reach(),
        new Aimbot(), new MacePvP(), new KillAura(), new AutoClicker(),
        new NoFall(), new Velocity(),
        new ESPChest(), new ESPPlayer(), new ESPEnemy(), new Tracers(), new Fullbright(),
        new ChestStealer(), new AutoArmor(), new AutoTotemModule(), new AutoEat(),
        new AutoTool(), new AirJump());

    /** Vrai si le module portant ce nom est activé. */
    public static boolean isEnabled(String name) {
        for (Hack h : modules) if (h.enabled && h.name.equals(name)) return true;
        return false;
    }

    private boolean wasDown;
    @Override public void onInitializeClient() {
        Config.load();
        for (Hack m : modules) if (!m.enabled && Config.autoEnabled(m.name)) m.toggle();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            // touche configurable dans le launcher (Shift droit par défaut)
            boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), Config.menuKey) == GLFW.GLFW_PRESS;
            if (down && !wasDown && mc.currentScreen == null && mc.player != null) mc.setScreen(new ClickGui());
            wasDown = down;
            if (mc.player != null) for (Hack m : modules) if (m.enabled) m.onTick();
        });
        HudRenderCallback.EVENT.register((g, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;
            // F2 : on cache le HUD pour que la capture soit propre (si activé dans le launcher)
            if (Config.hideOnScreenshot
                    && GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_F2) == GLFW.GLFW_PRESS) return;
            float td = tick.getTickProgress(false);
            for (Hack m : modules) if (m.enabled) m.onHud(g, td);

            var tr = mc.textRenderer;
            int accent = Config.accent;

            // Watermark arrondi (façon client moderne)
            String brand = "Vortex", ver = "2.0";
            int wm = 16 + tr.getWidth(brand) + 3 + tr.getWidth(ver);
            Ui.roundRect(g, 4, 4, 4 + wm, 19, 6, 0xCC0E0E13);
            Ui.roundRect(g, 4, 4, 7, 19, 3, accent);
            g.drawText(tr, brand, 11, 8, 0xFFFFFFFF, false);
            g.drawText(tr, ver, 11 + tr.getWidth(brand) + 3, 8, accent, false);

            // Liste des modules actifs, alignée à droite (du plus large au plus étroit)
            List<Hack> on = new java.util.ArrayList<>();
            for (Hack m : modules) if (m.enabled) on.add(m);
            on.sort((a, b) -> Integer.compare(tr.getWidth(b.name), tr.getWidth(a.name)));
            int y = 23;
            for (Hack m : on) {
                int w = tr.getWidth(m.name) + 13;
                int x2 = g.getScaledWindowWidth() - 4, x1 = x2 - w;
                Ui.roundRect(g, x1, y, x2, y + 13, 3, 0xAA0E0E13);
                Ui.roundRect(g, x2 - 2, y + 2, x2, y + 11, 1, accent);
                g.drawText(tr, m.name, x1 + 6, y + 3, 0xFFE8EAF3, false);
                y += 15;
            }
        });
    }
}
