$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root  = $PSScriptRoot
$tools = Join-Path $root "tools"
New-Item -ItemType Directory -Force $tools | Out-Null

function Get-Portable($name, $url) {
    $dest = Join-Path $tools $name
    if (Test-Path $dest) { return }
    Write-Host ">> Telechargement de $name ..."
    $zip = Join-Path $tools "$name.zip"; $tmp = Join-Path $tools "$name`_tmp"
    Invoke-WebRequest $url -OutFile $zip
    Expand-Archive $zip $tmp -Force
    Move-Item (Get-ChildItem $tmp)[0].FullName $dest
    Remove-Item $zip, $tmp -Recurse -Force
}

# 1) Java 21 + Gradle portables (dans .\tools, rien n'est installe sur le PC)
Get-Portable "jdk"    "https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse"
Get-Portable "gradle" "https://services.gradle.org/distributions/gradle-9.2.1-bin.zip"
$env:JAVA_HOME = Join-Path $tools "jdk"
$env:Path = "$env:JAVA_HOME\bin;$tools\gradle\bin;$env:Path"

# 2) Compilation du mod
Write-Host ">> Compilation du mod Vortex (quelques minutes la 1ere fois)..."
Push-Location (Join-Path $root "mod")
gradle build --no-daemon
if ($LASTEXITCODE -ne 0) { Pop-Location; throw "La compilation du mod a echoue. Copie l'erreur ci-dessus et envoie-la moi." }
Pop-Location
Copy-Item (Join-Path $root "mod\build\libs\vortex-client-2.0.jar") (Join-Path $root "launcher\vortex-client.jar") -Force

# 3) Python (pour fabriquer le .exe du launcher)
function Find-Python {
    foreach ($c in @("py", "python")) {
        $cmd = Get-Command $c -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source -notlike "*WindowsApps*") { return $c }
    }
    $p = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
    if (Test-Path $p) { return $p }
    return $null
}
$py = Find-Python
if (-not $py) {
    Write-Host ">> Installation de Python (winget, utilisateur uniquement)..."
    winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
    $py = Find-Python
}
if (-not $py) { throw "Python introuvable. Installe-le depuis python.org (coche 'Add to PATH') puis relance build.bat." }

Write-Host ">> Fabrication du launcher .exe ..."
& $py -m pip install --quiet -r (Join-Path $root "launcher\requirements.txt") pyinstaller
Push-Location (Join-Path $root "launcher")
& $py -m PyInstaller --onefile --noconsole --name "Vortex Client" --collect-all customtkinter --collect-all minecraft_launcher_lib --add-data "vortex-client.jar;." launcher.py
if ($LASTEXITCODE -ne 0) { Pop-Location; throw "PyInstaller a echoue." }
Pop-Location
Copy-Item (Join-Path $root "launcher\dist\Vortex Client.exe") (Join-Path $root "Vortex Client.exe") -Force
Write-Host ""
Write-Host "TERMINE ! Ouvre 'Vortex Client.exe' (dans ce dossier)." -ForegroundColor Green
