package fr.vortex.modules;

import fr.vortex.Hack;

/**
 * AutoTotem : remet un totem d'immortalité en main secondaire dès qu'elle est vide.
 * Utilise le helper partagé AutoTotem (un clic vanilla par slot, avec délai).
 */
public class AutoTotemModule extends Hack {

    public AutoTotemModule() { super("AutoTotem"); }

    @Override public void onTick() { AutoTotem.tick(); }
}
