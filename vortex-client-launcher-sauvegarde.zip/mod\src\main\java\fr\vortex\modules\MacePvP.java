package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * MacePvP : combo mace automatique, en actions 100 % vanilla.
 *
 * Séquence améliorée :
 *   1. cherche le joueur le plus proche (indépendamment du cône de l'Aimbot) ;
 *   2. décollage à la wind charge (main ou main secondaire, avec synchro du slot) ;
 *   3. mace en main, visée avec prédiction du mouvement de la cible ;
 *   4. approche contrôlée puis saut de critique si pas de wind charge ;
 *   5. frappe uniquement en descente : smash si la chute est suffisante, sinon critique.
 *
 * Rien d'impossible côté serveur : changement de slot, clic droit, attaque.
 */
public class MacePvP extends Hack {
    public static double RANGE = 6.0;          // détection / approche
    public static boolean AUTO_WALK = true;    // se rapproche tout seul
    public static double WALK_SPEED = 0.24;    // vitesse de marche
    public static boolean AUTO_JUMP = true;    // saute pour critique / smash
    public static boolean WIND_CHARGE = true;  // wind charge pour décoller
    public static double MIN_FALL = 1.2;       // chute mini pour le smash
    public static boolean CRIT = true;         // frappe aussi les petits sauts
    public static int WIND_COOLDOWN = 25;      // ticks entre deux wind charges
    public static double LEAD_TICKS = 3.0;     // prédiction de la cible
    public static double LAUNCH_RANGE = 4.5;   // distance max pour décoller
    public static boolean WALLS = false;

    private int windCooldown;
    private int attackDelay;
    private boolean launched;
    private boolean pendingWind;
    private int windPreviousSlot = -1;

    public MacePvP() { super("MacePvP"); }

    @Override public void onEnable() {
        windCooldown = 0;
        attackDelay = 0;
        launched = false;
        pendingWind = false;
        windPreviousSlot = -1;
    }

    @Override public void onDisable() {
        pendingWind = false;
        windPreviousSlot = -1;
    }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (windCooldown > 0) windCooldown--;
        if (attackDelay > 0) attackDelay--;

        PlayerEntity t = findTarget(RANGE);
        if (t == null || !t.isAlive()) {
            launched = false;
            return;
        }

        // le slot a été changé au tick précédent : le serveur est maintenant à jour
        if (pendingWind) {
            fireWind(Hand.MAIN_HAND);
            return;
        }

        double dist = p.distanceTo(t);
        double reach = p.getEntityInteractionRange();

        // on a touché le sol : on peut relancer un combo
        if (p.isOnGround() && p.fallDistance < 0.1) launched = false;

        // 1) décollage à la wind charge
        if (WIND_CHARGE && !launched && windCooldown == 0 && p.isOnGround()
                && dist <= LAUNCH_RANGE) {
            int slot = findHotbar(Items.WIND_CHARGE);
            if (slot >= 0) {
                windPreviousSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                pendingWind = true;          // le serveur recevra le slot au tick suivant
                return;
            }
            if (p.getOffHandStack().isOf(Items.WIND_CHARGE)) {
                fireWind(Hand.OFF_HAND);
                return;
            }
        }

        // 2) mace en main (attendre un tick pour la synchro serveur)
        int mace = findHotbar(Items.MACE);
        if (mace < 0) return;
        if (p.getInventory().getSelectedSlot() != mace) {
            p.getInventory().setSelectedSlot(mace);
            return;
        }

        // 3) visée avec prédiction du déplacement
        Aimbot.lookAtPredicted(t, LEAD_TICKS);

        // 4) approche : on s'arrête à distance de frappe
        if (AUTO_WALK) {
            double stop = Math.max(1.6, reach - 0.8);
            if (dist > stop) {
                Vec3d d = new Vec3d(t.getX() - p.getX(), 0, t.getZ() - p.getZ());
                if (d.lengthSquared() > 1e-4) {
                    d = d.normalize();
                    Vec3d v = p.getVelocity();
                    double speed = p.isOnGround()
                            ? WALK_SPEED
                            : Math.max(WALK_SPEED * 0.9, Math.hypot(v.x, v.z));
                    p.setVelocity(d.x * speed, v.y, d.z * speed);
                }
            }
        }

        if (dist > reach) return;

        // 5) saut critique quand aucune wind charge n'est partie
        if (AUTO_JUMP && p.isOnGround() && !launched) p.jump();

        // 6) frappe en descente uniquement
        if (attackDelay > 0) return;
        if (p.getAttackCooldownProgress(0f) < 0.95f) return;
        boolean falling = !p.isOnGround() && p.getVelocity().y < -0.02;
        boolean smash = falling && p.fallDistance >= MIN_FALL;
        boolean crit = CRIT && falling && p.fallDistance > 0.2;
        if (!smash && !crit) return;

        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        attackDelay = smash ? 4 : 6;
        if (smash) launched = false;
    }

    /** Utilise la wind charge vers le sol et restaure le slot précédent. */
    private void fireWind(Hand hand) {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) {
            pendingWind = false;
            return;
        }
        float previousPitch = p.getPitch();
        p.setPitch(89f);
        if (p.networkHandler != null) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                p.getYaw(), 89f, p.isOnGround(), p.horizontalCollision));
        }
        mc.interactionManager.interactItem(p, hand);
        p.setPitch(previousPitch);
        if (hand == Hand.MAIN_HAND && windPreviousSlot >= 0) {
            p.getInventory().setSelectedSlot(windPreviousSlot);
        }
        windPreviousSlot = -1;
        pendingWind = false;
        launched = true;
        windCooldown = Math.max(1, WIND_COOLDOWN);
    }

    private static PlayerEntity findTarget(double range) {
        PlayerEntity best = null;
        double bestDist = range * range;
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == mc.player || !other.isAlive() || other.isSpectator()) continue;
            double d = mc.player.squaredDistanceTo(other);
            if (d >= bestDist) continue;
            if (!WALLS && !mc.player.canSee(other)) continue;
            bestDist = d;
            best = other;
        }
        return best;
    }

    private static int findHotbar(Item item) {
        var p = mc.player;
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }
}
