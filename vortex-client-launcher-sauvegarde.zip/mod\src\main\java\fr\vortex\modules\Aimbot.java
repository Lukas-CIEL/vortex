package fr.vortex.modules;

import fr.vortex.Hack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Aimbot « legit » : vise la cible la plus proche DU VISEUR, avec lissage,
 * temps de réaction, prédiction du déplacement et verrouillage de cible.
 *
 * Par défaut il n'agit QUE quand tu maintiens le clic gauche (ON_CLICK) :
 * tu peux marcher, builder et regarder ailleurs sans que la caméra bouge.
 */
public class Aimbot extends Hack {
    public static double RANGE = 4.2;          // portée de recherche
    public static double FOV = 55.0;           // cône de recherche, en degrés
    public static double AIM_HEIGHT = 0.80;    // 0 = pieds, 1 = tête
    public static float TURN = 0.18f;          // lissage (1 = verrouillage instantané)
    public static float MAX_STEP = 3.5f;       // rotation max par tick (anti-snap)
    public static boolean AUTO_ATTACK = false; // frappe automatique
    public static boolean WALLS = false;       // viser aussi à travers les murs
    public static boolean ON_CLICK = true;     // n'agir que clic gauche maintenu
    public static int SEND_EVERY = 3;          // envoie la rotation un tick sur N
    public static int REACTION_MS = 140;       // délai avant de viser une nouvelle cible
    public static int SWITCH_MS = 350;         // délai mini entre deux changements de cible
    public static double JITTER = 0.20;        // tremblement (degrés) pour rester humain
    public static double PREDICT = 1.5;        // ticks d'avance sur la cible

    private static final Random RNG = new Random();

    private static PlayerEntity target;
    private static int tick;
    private static float lastYaw, lastPitch;
    private static int targetId = -1;
    private static long acquiredAt;
    private static long switchedAt;

    public Aimbot() { super("Aimbot"); }

    /** Cible : la meilleure combinaison distance + angle par rapport au viseur. */
    public static PlayerEntity nearest(double range) {
        PlayerEntity best = null;
        double bestScore = Double.MAX_VALUE;
        if (mc.world == null || mc.player == null) return null;
        Vec3d eye = mc.player.getEyePos();
        Vec3d look = mc.player.getRotationVec(1f);
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            double d = mc.player.squaredDistanceTo(p);
            if (d > range * range) continue;
            if (!WALLS && !mc.player.canSee(p)) continue;
            Vec3d dir = p.getEyePos().subtract(eye);
            double len = dir.length();
            double angle = 0;
            if (len > 1e-4) {
                double cos = dir.dotProduct(look) / len;
                angle = Math.toDegrees(Math.acos(MathHelper.clamp(cos, -1.0, 1.0)));
            }
            if (angle > FOV / 2) continue;
            double score = d * 0.35 + angle;
            if (score < bestScore) { bestScore = score; best = p; }
        }
        return best;
    }

    /** Point visé : position actuelle + déplacement prévu. */
    public static Vec3d pointOf(PlayerEntity t, double ticks) {
        Vec3d v = t.getVelocity();
        return new Vec3d(
            t.getX() + v.x * ticks,
            t.getY() + t.getHeight() * AIM_HEIGHT + Math.max(0, v.y) * ticks * 0.5,
            t.getZ() + v.z * ticks);
    }

    /** Angle (degrés) entre le viseur et la cible. */
    public static double angleTo(PlayerEntity t) {
        if (mc.player == null) return 180;
        Vec3d dir = t.getEyePos().subtract(mc.player.getEyePos());
        double len = dir.length();
        if (len < 1e-4) return 0;
        double cos = dir.dotProduct(mc.player.getRotationVec(1f)) / len;
        return Math.toDegrees(Math.acos(MathHelper.clamp(cos, -1.0, 1.0)));
    }

    /** Rotation immédiate + envoi au serveur (utilisé par MacePvP). */
    public static void lookAt(PlayerEntity t) { rotatePoint(pointOf(t, 0), 1f, true, 180f); }

    /** Idem, mais vise la position future de la cible (prédiction en ticks). */
    public static void lookAtPredicted(PlayerEntity t, double ticks) {
        rotatePoint(pointOf(t, ticks), 1f, true, 180f);
    }

    /** Rotation progressive, pour KillAura (ne snap pas d'un coup). */
    public static void aimPoint(Vec3d point) { rotatePoint(point, 0.55f, true, 32f); }

    private static void rotatePoint(Vec3d point, float factor, boolean send, float maxStep) {
        if (mc.player == null) return;
        Vec3d eye = mc.player.getEyePos();
        double dx = point.x - eye.x;
        double dy = point.y - eye.y;
        double dz = point.z - eye.z;
        float wantYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        float yawDelta = MathHelper.wrapDegrees(wantYaw - mc.player.getYaw());
        float pitchDelta = wantPitch - mc.player.getPitch();
        yawDelta = MathHelper.clamp(yawDelta * factor, -maxStep, maxStep);
        pitchDelta = MathHelper.clamp(pitchDelta * factor, -maxStep, maxStep);
        float yaw = mc.player.getYaw() + yawDelta;
        float pitch = MathHelper.clamp(mc.player.getPitch() + pitchDelta, -90f, 90f);
        if (JITTER > 0 && factor < 0.9f) {
            yaw += (float) ((RNG.nextDouble() - 0.5) * 2.0 * JITTER);
            pitch += (float) ((RNG.nextDouble() - 0.5) * 2.0 * JITTER);
        }
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
        if (!send || mc.player.networkHandler == null) return;
        if (SEND_EVERY > 1 && (tick % SEND_EVERY) != 0) return;
        if (Math.abs(yaw - lastYaw) < 0.01f && Math.abs(pitch - lastPitch) < 0.01f) return;
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
            yaw, pitch, mc.player.isOnGround(), mc.player.horizontalCollision));
        lastYaw = yaw;
        lastPitch = pitch;
    }

    @Override public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tick++;

        long now = System.currentTimeMillis();
        PlayerEntity t = nearest(RANGE);

        // éviter de zapper d'une cible à l'autre toutes les 50 ms
        if (t != null && target != null && t != target && target.isAlive()
                && now - switchedAt < SWITCH_MS
                && mc.player.squaredDistanceTo(target) <= RANGE * RANGE * 1.2
                && (WALLS || mc.player.canSee(target))) {
            t = target;
        }
        if (t != target) switchedAt = now;
        target = t;
        if (t == null) {
            targetId = -1;
            return;
        }

        // temps de réaction avant de verrouiller une nouvelle cible
        if (t.getId() != targetId) {
            targetId = t.getId();
            acquiredAt = now;
        }
        if (now - acquiredAt < REACTION_MS) return;
        if (mc.currentScreen != null) return;

        // par défaut : on aide seulement pendant l'attaque
        if (ON_CLICK && !mc.options.attackKey.isPressed()) return;

        double angle = angleTo(t);
        float factor = TURN;
        if (angle < 5) factor *= 0.55f;        // petit ajustement = plus doux
        else if (angle > 30) factor *= 1.5f;   // grande correction = un peu plus vite
        if (factor > 1f) factor = 1f;

        rotatePoint(pointOf(t, PREDICT), factor, true, MAX_STEP);

        if (!AUTO_ATTACK || mc.interactionManager == null) return;
        double reach = mc.player.getEntityInteractionRange();
        if (mc.player.squaredDistanceTo(t) > reach * reach) return;
        if (!WALLS && !mc.player.canSee(t)) return;
        Vec3d look = mc.player.getRotationVec(1f);
        Vec3d dir = t.getEyePos().subtract(mc.player.getEyePos()).normalize();
        if (look.dotProduct(dir) < 0.985) return;
        if (mc.player.getAttackCooldownProgress(0f) < 0.98f) return;
        mc.interactionManager.attackEntity(mc.player, t);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    public static PlayerEntity getTarget() { return target; }
}
