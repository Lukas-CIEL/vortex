package fr.vortex.modules;
import fr.vortex.Hack;
/**
 * Sprint : force le sprint dès qu'on avance, même avec peu de faim.
 * C'est une action vanilla côté client (le serveur reçoit juste « je sprinte »),
 * donc indétectable par un anticheat de mouvement.
 */
public class Sprint extends Hack {
    public static boolean REQUIRE_HUNGER = true;   // ne pas sprinter sous 3 demi-briques de faim

    public Sprint() { super("Sprint"); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (!p.input.playerInput.forward() || p.isSneaking() || p.isUsingItem()) return;
        if (REQUIRE_HUNGER && p.getHungerManager().getFoodLevel() <= 6) return;
        p.setSprinting(true);
    }
}
