# Compile l'APK "Vortex Remote" sans Android Studio (aapt2 + javac + d8 + apksigner).
# Usage : .\build_android.ps1
# Le SDK Android est cherché dans ANDROID_SDK_ROOT, puis dans le dossier temporaire du projet.
$ErrorActionPreference = "Stop"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
$out = Join-Path $root "launcher\Vortex Remote.apk"

$sdk = $env:ANDROID_SDK_ROOT
if (-not $sdk) { $sdk = $env:ANDROID_HOME }
if (-not $sdk -or -not (Test-Path $sdk)) {
    $sdk = Join-Path $env:LOCALAPPDATA "Temp\opencode\android-sdk"
}
$buildTools = Join-Path $sdk "build-tools\34.0.0"
$androidJar = Join-Path $sdk "platforms\android-34\android.jar"
if (-not (Test-Path $androidJar)) { throw "SDK Android introuvable ($androidJar). Installe platforms;android-34." }

$aapt2 = Join-Path $buildTools "aapt2.exe"
$d8 = Join-Path $buildTools "d8.bat"
$zipalign = Join-Path $buildTools "zipalign.exe"
$apksigner = Join-Path $buildTools "apksigner.bat"

$javaHome = $env:JAVA_HOME
if (-not $javaHome) { $javaHome = Join-Path $root "tools\jdk" }
$javac = Join-Path $javaHome "bin\javac.exe"
$keytool = Join-Path $javaHome "bin\keytool.exe"
$jar = Join-Path $javaHome "bin\jar.exe"
if (-not (Test-Path $javac)) { throw "javac introuvable ($javac)." }

$b = Join-Path $here "build"
if (Test-Path $b) { Remove-Item $b -Recurse -Force }
New-Item -ItemType Directory -Path $b | Out-Null

Write-Host "1/6  ressources (aapt2 compile)"
& $aapt2 compile --dir (Join-Path $here "res") -o (Join-Path $b "res.zip")
if ($LASTEXITCODE -ne 0) { throw "aapt2 compile a échoué" }

Write-Host "2/6  manifeste (aapt2 link)"
& $aapt2 link -o (Join-Path $b "base.apk") -I $androidJar `
    --manifest (Join-Path $here "AndroidManifest.xml") `
    -R (Join-Path $b "res.zip") --java (Join-Path $b "gen") --auto-add-overlay
if ($LASTEXITCODE -ne 0) { throw "aapt2 link a échoué" }

Write-Host "3/6  java (javac)"
$gen = Join-Path $b "gen\com\vortex\remote\R.java"
$classes = Join-Path $b "classes"
New-Item -ItemType Directory -Path $classes | Out-Null
& $javac -source 8 -target 8 -nowarn -bootclasspath $androidJar -encoding UTF-8 `
    -d $classes (Join-Path $here "src\com\vortex\remote\MainActivity.java") $gen
if ($LASTEXITCODE -ne 0) { throw "javac a échoué" }

Write-Host "4/6  dex (d8)"
& $jar cf (Join-Path $b "classes.jar") -C $classes .
$dexDir = Join-Path $b "dex"
New-Item -ItemType Directory -Path $dexDir | Out-Null
& $d8 --release --lib $androidJar --min-api 21 --output $dexDir (Join-Path $b "classes.jar")
if ($LASTEXITCODE -ne 0) { throw "d8 a échoué" }

Write-Host "5/6  assemblage + alignement"
Add-Type -AssemblyName System.IO.Compression.FileSystem
$apk = Join-Path $b "unsigned.apk"
Copy-Item (Join-Path $b "base.apk") $apk
$zip = [System.IO.Compression.ZipFile]::Open($apk, "Update")
try {
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
        $zip, (Join-Path $dexDir "classes.dex"), "classes.dex",
        [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
} finally { $zip.Dispose() }

$aligned = Join-Path $b "aligned.apk"
& $zipalign -f 4 $apk $aligned
if ($LASTEXITCODE -ne 0) { throw "zipalign a échoué" }

Write-Host "6/6  signature"
$ks = Join-Path $here "debug.keystore"
if (-not (Test-Path $ks)) {
    & $keytool -genkeypair -keystore $ks -storepass android -keypass android -alias vortex `
        -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Vortex Remote, O=Vortex, C=FR"
    if ($LASTEXITCODE -ne 0) { throw "keytool a échoué" }
}
& $apksigner sign --ks $ks --ks-pass pass:android --key-pass pass:android --out $out $aligned
if ($LASTEXITCODE -ne 0) { throw "apksigner a échoué" }
& $apksigner verify --print-certs $out | Select-Object -First 3

Get-Item $out | Select-Object Name, Length, LastWriteTime | Format-Table -AutoSize
Write-Host "APK prêt : $out"
